<?php
session_start();
include 'connect.php';

if (isset($_SESSION['user_id'])) {
    echo json_encode(["logged_in" => true]);
} else {
    echo json_encode(["logged_in" => false]);
}
exit;

?>
