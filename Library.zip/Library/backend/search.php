<?php
session_start();
include("connect.php"); 

//VOICE SEARCH JSON
if (isset($_GET['GETvoicesearch'])) {
    $voicetypequery = $conn->real_escape_string($_GET['GETvoicesearch']);

    $keywords = explode(" ", $voicetypequery);

    // Build dynamic SQL conditions
    $conditions = [];
    foreach ($keywords as $word) {
        $safeWord = $conn->real_escape_string($word);
        $conditions[] = "(booktitle LIKE '%$safeWord%' OR genre LIKE '%$safeWord%' OR bookauthor LIKE '%$safeWord%')";
    }

    $whereClause = implode(" OR ", $conditions);
    $sql = "SELECT * FROM booktry WHERE $whereClause";

    // $sql = "SELECT * FROM booktry WHERE booktitle LIKE '%$voicetypequery%' OR genre LIKE '%$voicetypequery%' OR bookauthor LIKE '%$voicetypequery%'";
    $result = $conn->query($sql);

    $books = [];
    while ($row = $result->fetch_assoc()) {
        $books[] = [
            'title' => $row['booktitle'],
            'author' => $row['bookauthor'],   
            'category' => $row['genre'],
            'pub_year' => $row['bookpublished']
        ];
        
    }    
    echo json_encode($books);
}

//TEXT SEARCH JSON
if(isset($_GET['GETtextsearch'])){
    $textsearchquery = $_GET['GETtextsearch'];
    $antisql_textsearch = preg_replace("#[^0-9a-z]#i","",$textsearchquery);
    
    $text_search = explode(" ", $textsearchquery);

    $text_search_array = [];
    foreach ($text_search as $word) {
        $text_search_querystatement = $conn->real_escape_string($word);
        $text_search_array[] = "(booktitle LIKE '%$text_search_querystatement%' OR bookauthor LIKE '%$text_search_querystatement%'
         OR genre LIKE '%$text_search_querystatement%' OR bookpublished LIKE '%$text_search_querystatement%' )";
    }

    $whereClause = implode(" OR ", $text_search_array);
    
    $sql = "SELECT * FROM booktry WHERE $whereClause";
    $result = $conn->query($sql);
    
     $textbooklist = [];   
     while($row = $result->fetch_assoc()) {
        $textbooklist[] = [
            'text_title' => $row['booktitle'],
            'text_author' => $row['bookauthor'],
            'text_genre' => $row['genre'],
            'text_pubyear' => $row['bookpublished']
        ];
        if (!isset($_SESSION['book_title'])) {
        $_SESSION['book_title'] = $row['booktitle'];
        }      
     }
     echo json_encode($textbooklist);  // Send data as JSON response
}

$conn->close();
?>