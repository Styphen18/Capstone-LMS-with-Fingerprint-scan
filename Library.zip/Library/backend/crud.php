<?php
include 'connect.php';
header('Content-Type: application/json; charset=UTF-8');

function safeAttr($value) {
    return htmlspecialchars(trim(str_replace(["\n", "\r"], '', $value)), ENT_QUOTES);
}

// Pagination variables
$limit = 8; // Items per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1); // Prevent negative or zero page
$offset = ($page - 1) * $limit;

// Count total number of books
$totalQuery = $conn->query("SELECT COUNT(*) AS total FROM booktry");
$totalRow = $totalQuery->fetch_assoc();
$totalBooks = $totalRow['total'];
$totalPages = ceil($totalBooks / $limit);

// Fetch paginated books
$sql = "SELECT * FROM booktry ORDER BY id DESC LIMIT $offset, $limit";
$result = $conn->query($sql);

// Build book rows
$bookRows = "";
while ($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $title = safeAttr($row['booktitle']);
    $author = safeAttr($row['bookauthor']);
    $published = safeAttr($row['bookpublished']);
    $quantity = safeAttr($row['bookquantity']);
    $genre = safeAttr($row['genre']);
    $entry = safeAttr($row['bookentry']);

    $bookRows .= "
    <tr id='book-row-{$id}'>
        <td>{$id}</td>
        <td>{$title}</td>
        <td>{$author}</td>
        <td>{$published}</td>
        <td>{$quantity}</td>
        <td>{$genre}</td>
        <td>{$entry}</td>
        <td>
            <a href='#' class='btn btn-primary btn-sm update-btn'
               data-id='{$id}'
               data-title=\"{$title}\"
               data-author=\"{$author}\"
               data-published=\"{$published}\"
               data-quantity=\"{$quantity}\"
               data-genre=\"{$genre}\">Update</a>
            <a href='#' class='btn btn-danger btn-sm' onclick='deleteBook(\"{$id}\")'>Delete</a>
        </td>
    </tr>
    ";
}

// Return JSON
echo json_encode([
    'books' => $bookRows,
    'totalPages' => $totalPages
]);
?>
