// ======================================================================= get and show user account with pagination
// take user data from the server (acc_crud.php) and updates the user table.
function loadUsers(page = 1) {
  fetch('../backend/acc_crud.php?page=${page}') 
    .then(response => response.json())
    .then(data => {
      document.getElementById('userTableBody').innerHTML = data.users;
      setupUserPagination(data.totalPages, page);
    })
    .catch(error => {
      document.getElementById('userTableBody').innerHTML = "Error loading user list.";
      console.error("Error loading acc_crud.php:", error);
    });
}

// ======================================================================= Setup Pagination for User List
// Dynamically generates pagination buttons based on total number of pages.
// Highlights the current page and attaches click events to load corresponding user data
function setupUserPagination(totalPages, currentPage) {
  const pagination = document.getElementById('userpagination');
  pagination.innerHTML = '';

  for (let i = 1; i <= totalPages; i++) {
    const li = document.createElement('li');
    li.classList.add('page-item');
    if (i === currentPage) li.classList.add('active');

    const a = document.createElement('a');
    a.classList.add('page-link');
    a.href = '#';
    a.textContent = i;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      loadUsers(i);
    });

    li.appendChild(a);
    pagination.appendChild(li);
  }
}

// ======================================================================= get user value and put it in admin   
function submitAddAccount(event) {
  event.preventDefault();

  const fullname = document.getElementById('fullname').value.trim();
  const yrcourse = document.getElementById('yrcourse').value.trim();
  const studentid = document.getElementById('studentid').value.trim();
  const contact = document.getElementById('contact').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();

  if (!fullname || !yrcourse || !studentid || !contact || !email || !password) {
    alert("Please fill in all required fields.");
    return;
  }

  fetch('../backend/acc_crud.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 
      'fullname=' + encodeURIComponent(fullname) +
      '&yrcourse=' + encodeURIComponent(yrcourse) +
      '&studentid=' + encodeURIComponent(studentid) +
      '&contact=' + encodeURIComponent(contact) +
      '&email=' + encodeURIComponent(email) +
      '&password=' + encodeURIComponent(password)
  })
  .then(response => response.text())
  .then(data => {
    console.log(data);
    closeUserModal();
    document.getElementById("accForm").reset();
    showPanel('employee');
  })
  .catch(error => {
    alert("Error: " + error);
  });
}
// ============================================================================ MODAL FOR USER 
function openUpdateModaluser(id, name, department, studentId, contact, email) {
  document.getElementById('userId').value = id;
  document.getElementById('fullname').value = name;
  document.getElementById('yrcourse').value = department;
  document.getElementById('studentid').value = studentId;
  document.getElementById('contact').value = contact;
  document.getElementById('email').value = email;
  document.getElementById('password').value = ""; // always empty

  document.querySelector('#userModal h2').textContent = "Update Account";
  document.querySelector('#accForm button[type="submit"]').textContent = "Update";
  document.getElementById('accForm').onsubmit = submitUpdateAccount;

  document.getElementById('userModal').style.display = "flex";
}
// ============================================================================ UPDATE ACCOUNT 
document.addEventListener('DOMContentLoaded', function () {
  // All your event listeners and functions go inside this block

  document.addEventListener('click', function (e) {
    if (e.target.classList.contains('update-btn-user')) {
      e.preventDefault();

      const btn = e.target;
      document.getElementById('userId').value = btn.dataset.id;
      document.getElementById('fullname').value = btn.dataset.name;
      document.getElementById('yrcourse').value = btn.dataset.department;
      document.getElementById('studentid').value = btn.dataset.student_id;
      document.getElementById('contact').value = btn.dataset.contact;
      document.getElementById('email').value = btn.dataset.email;
      document.getElementById('password').value = ""; // clear for security

      document.querySelector('#userModal h2').textContent = "Update Account";
      document.querySelector('#accForm button[type="submit"]').textContent = "Update";
      document.getElementById('accForm').onsubmit = submitUpdateAccount;
      document.getElementById('userModal').style.display = "flex";
    }
  });

  function submitUpdateAccount(event) {
    event.preventDefault();

    const id = document.getElementById('userId').value;
    const fullname = document.getElementById('fullname').value.trim();
    const yrcourse = document.getElementById('yrcourse').value.trim();
    const studentid = document.getElementById('studentid').value.trim();
    const contact = document.getElementById('contact').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    fetch('../backend/acc_crud.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body:
        'id=' + encodeURIComponent(id) +
        '&fullname=' + encodeURIComponent(fullname) +
        '&yrcourse=' + encodeURIComponent(yrcourse) +
        '&studentid=' + encodeURIComponent(studentid) +
        '&contact=' + encodeURIComponent(contact) +
        '&email=' + encodeURIComponent(email) +
        '&password=' + encodeURIComponent(password)
    })
    .then(response => response.text())
    .then(data => {
      console.log(data);
      closeUserModal();
      document.getElementById("accForm").reset();
      showPanel('employee');

      showCustomAlert("Account updated successfully!");
    })
    .catch(error => {
      alert("Error: " + error);
    });
  }
});

// show allert for update successfully
function showCustomAlert(message = "Account updated successfully!") {
  const alert = document.getElementById('alert_update');
  alert.textContent = message;
  alert.style.display = 'block';

  
  alert.classList.remove('alert_update'); 
  void alert.offsetWidth; 
  alert.classList.add('alert_update'); 

  setTimeout(() => {
    alert.style.display = 'none';
  }, 1500);
}


function openUserModal() {
  document.getElementById('accForm').reset();
  document.getElementById('userId').value = "";

  document.querySelector('#userModal h2').textContent = "Add Account";
  document.querySelector('#accForm button[type="submit"]').textContent = "Add";
  document.getElementById('accForm').onsubmit = submitAddAccount;

  document.getElementById("userModal").style.display = "flex";
}

function closeUserModal() {
  document.getElementById('userModal').style.display = "none";
  document.getElementById('accForm').reset();
  document.getElementById('userId').value = "";
  document.getElementById('accForm').onsubmit = submitAddAccount;
}

// ============================================================================ Delete user function
function deleteUser(userId) {
  const dialog = document.getElementById('userdialog');
  dialog.style.display = 'block';

  const yesBtn = document.getElementById('users-yes');
  const noBtn = document.getElementById('users-no');

  // Clear previous event listeners
  yesBtn.onclick = null;
  noBtn.onclick = null;

  yesBtn.onclick = (e) => {
    e.preventDefault();
    dialog.style.display = 'none';

    // Keep the original PHP call from second function
    fetch('../backend/delete_account.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `action=delete&id=${encodeURIComponent(userId)}`
    })
    .then(response => response.json())
    .then(data => {
      alert(data.message);
      if (data.status === 'success') {
        loadUsers(); // Call to refresh the user list
      }
    })
    .catch(error => {
      alert("Error deleting user.");
      console.error("Delete error:", error);
    });
  };

  noBtn.onclick = () => {
    dialog.style.display = 'none';
  };
}