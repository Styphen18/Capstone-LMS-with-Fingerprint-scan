// ======================================================================= get and show borrowing logs with pagination
function loadBorrowingLogs(page = 1) {
  fetch(`../backend/borrowing_management.php?page=${page}`)
    .then(response => response.json())
    .then(data => {
      document.getElementById('borrowTableBody').innerHTML = data.borrows;
      setupBorrowPagination(data.totalPages, page);
    })
    .catch(error => {
      document.getElementById('borrowTableBody').innerHTML = "Error loading borrowing list.";
      console.error("Error loading borrowing_management.php:", error);
    });
}

// ======================================================================= Setup Pagination for Borrowing Logs
function setupBorrowPagination(totalPages, currentPage) {
  const pagination = document.getElementById('borrowPagination');
  pagination.innerHTML = '';

  for (let i = 1; i <= totalPages; i++) {
    const li = document.createElement('li');
    li.classList.add('page-item');
    if (i === currentPage) li.classList.add('active');

    const a = document.createElement('a');
    a.classList.add('page-link');
    a.href = '#';
    a.textContent = i;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      loadBorrowingLogs(i);
    });

    li.appendChild(a);
    pagination.appendChild(li);
  }
}
// ======================================================================= approved conditon Status
function updateBorrowStatus(borrowId) {
  if (!confirm("Approve this borrow request?")) return;

  fetch('../backend/update_borrow_status.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'borrow_id=' + encodeURIComponent(borrowId)
  })
  .then(response => response.json())
  .then(data => {
    alert(data.message);
    if (data.status === 'success') {
      loadBorrowingLogs(); // Or showPanel('borrowPanel') if needed
    }
  })
  .catch(error => {
    console.error("Error approving borrow:", error);
    alert("Failed to update borrow status.");
  });
}


// ======================================================================= Delete Borrow Log
 function deleteBorrowLog(id) 
 {
  const dialog = document.getElementById('borrowdialog');
  dialog.style.display = 'block';

  const yesBtn = document.getElementById('borrow-yes');
  const noBtn = document.getElementById('borrow-no');

  // Clear previous event listeners
  yesBtn.onclick = null;
  noBtn.onclick = null;

  yesBtn.onclick = (e) => {
    e.preventDefault();
    dialog.style.display = 'none';

    // Keep the original PHP call from second function
    fetch('../backend/reject_borrowing.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `action=delete&borrow_id=${encodeURIComponent(id)}`
    })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        const alert_reject = document.getElementById('alert_borrowing');
        alert_reject.style.display='block';

        setTimeout(() => {
           alert_reject.style.display='none';
        }, 1500);
        loadBorrowingLogs() // Call to refresh the user list
      }
      else{alert(data.message);}
    })
    .catch(error => {
      alert("Error rejecting request.");
      console.error("Delete error:", error);
    });
  };

  noBtn.onclick = () => {
    dialog.style.display = 'none';
  };
}
//  {
//   if (confirm("Are you sure you want to reject this borrow record?")) {
//     fetch('../backend/reject_borrowing.php', {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
//       body: `action=delete&borrow_id=${encodeURIComponent(id)}`
//     })
//     .then(response => response.json())
//     .then(data => {
//       alert("Deleted successfully");
//       loadBorrowingLogs();
//     })
//     .catch(error => alert("Error deleting borrow record: " + error));
//   }
// }

