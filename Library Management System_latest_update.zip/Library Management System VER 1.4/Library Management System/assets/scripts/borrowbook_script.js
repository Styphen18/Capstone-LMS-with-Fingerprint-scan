function autofillform(){
    fetch("../backend/user_type.php")
    .then(response => response.json())
    .then(data => {
        // Borrow book date
        const today = new Date();
        const borrowdate = new Date().toISOString().split('T')[0];
        // Return book date
        const returnDateObj = new Date(today);

        if (data.usertype == "Student") {
            returnDateObj.setDate(today.getDate() + 2);
        } else if (data.usertype == "Teacher") {
            returnDateObj.setDate(today.getDate() + 3);
        }
        const returndate = returnDateObj.toISOString().split('T')[0];
        
        fetch("../backend/autofill_form.php")
        .then(response => response.json())
        .then(data => {
            if (data.user) {
                console.log("Autofill data:", data); // ← Add this
                document.getElementById("form-name").value = data.user.fullname || "";
                document.getElementById("form-yearandcourse").value = data.user.yrcourse || "";
                document.getElementById("form-studentid").value = data.user.studentid || "";
                document.getElementById("form-contact").value = data.user.contact || "";
                document.getElementById("form-borrowbookdate").value = borrowdate;
                document.getElementById("form-bookreturn").value = returndate;
                document.getElementById("form-email").value = data.user.email || "";
            }
            if (data.book) {
                console.log("Autofill data:", data); 
                document.getElementById("form-booktitle").value = data.book.booktitle || "";
                document.getElementById("form-accno").value = data.book.acc_no || "";
                document.getElementById("form-callno").value = data.book.call_no || "";
            }
        });
    })
}

document.addEventListener("DOMContentLoaded", autofillform);
