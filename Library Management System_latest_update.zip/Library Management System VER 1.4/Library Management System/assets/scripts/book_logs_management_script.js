// ======================================================================= get and show borrowing logs with pagination
function loadBorrowingLogs_logs(page = 1) {
  fetch(`../backend/book_logs_management.php?page=${page}`)
    .then(response => response.json())
    .then(data => {
      document.getElementById('borrowTableBody_logs').innerHTML = data.borrows_logs;
      setupBorrowPagination_logs(data.totalPages, page);
    })
    .catch(error => {
      document.getElementById('borrowTableBody_logs').innerHTML = "Error loading borrowing list.";
      console.error("Error loading book_logs_management.php:", error);
    });
}

// ======================================================================= Setup Pagination for Borrowing Logs
function setupBorrowPagination_logs(totalPages, currentPage) {
  const pagination = document.getElementById('borrowPagination_logs');
  pagination.innerHTML = '';

  for (let i = 1; i <= totalPages; i++) {
    const li = document.createElement('li');
    li.classList.add('page-item');
    if (i === currentPage) li.classList.add('active');

    const a = document.createElement('a');
    a.classList.add('page-link');
    a.href = '#';
    a.textContent = i;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      loadBorrowingLogs_logs(i);
    });

    li.appendChild(a);
    pagination.appendChild(li);
  }
}
