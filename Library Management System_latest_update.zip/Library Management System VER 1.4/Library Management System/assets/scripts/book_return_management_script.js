// ======================================================================= get and show borrowing logs with pagination
function loadBorrowingLogs_return(page = 1) {
  fetch(`../backend/book_return_management.php?page=${page}`)
    .then(response => response.json())
    .then(data => {
      document.getElementById('borrowTableBody_return').innerHTML = data.borrows_return;
      setupBorrowPagination_return(data.totalPages, page);
    })
    .catch(error => {
      document.getElementById('borrowTableBody_return').innerHTML = "Error loading borrowing list.";
      console.error("Error loading book_return_management.php:", error);
    });
}

// ======================================================================= Setup Pagination for Borrowing Logs
function setupBorrowPagination_return(totalPages, currentPage) {
  const pagination = document.getElementById('borrowPagination_return');
  pagination.innerHTML = '';

  for (let i = 1; i <= totalPages; i++) {
    const li = document.createElement('li');
    li.classList.add('page-item');
    if (i === currentPage) li.classList.add('active');

    const a = document.createElement('a');
    a.classList.add('page-link');
    a.href = '#';
    a.textContent = i;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      loadBorrowingLogs_return(i);
    });

    li.appendChild(a);
    pagination.appendChild(li);
  }
}

function update_to_returned(id) {
  if (confirm("Are you sure the book is already returned?")) {
    fetch('../backend/update_status_return.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `action=delete&borrow_id=${encodeURIComponent(id)}`
    })
    .then(response => response.json())
    .then(data => {
      alert("The book is returned successfully");
      loadBorrowingLogs_return();
    })
    // .catch(error => console.log(error));
  }
}
