<?php
include '../connect.php';

header('Content-Type: application/json');

$result = $conn->query("SELECT COUNT(*) AS reports FROM report_issue");

if ($result) {
    $row = $result->fetch_assoc();
    echo $row['reports'];
} else {
    echo json_encode(['reports' => 0]);
}
