<?php
include 'connect.php';

$sql = "SELECT * FROM report_issue ORDER BY reported_date DESC";
$result = $conn->query($sql);

$rows = '';
while ($row = $result->fetch_assoc()) {
    $rows .= "<tr>
        <td>" . htmlspecialchars($row['name']) . "</td>
        <td>" . htmlspecialchars($row['course']) . "</td>
        <td>" . htmlspecialchars($row['student_id']) . "</td>
        <td>" . htmlspecialchars($row['book_title']) . "</td>
        <td>" . htmlspecialchars($row['issue_type']) . "</td>
        <td>" . htmlspecialchars($row['reported_date']) . "</td>
    </tr>";
}

echo $rows;
