<?php
include 'connect.php';
session_start();

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM borrowrequest_logs WHERE borrow_user_id = '$user_id' AND (borrow_status = 'pending' OR borrow_status = 'approved')";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<p><b>Title:</b> " . htmlspecialchars($row['borrow_booktitle']) . "<br>";
        echo "<b>Status:</b> " . $row['borrow_status'] . "<br>";
        echo "<b>Borrowed:</b> " . $row['borrow_date'] . "<br>";
        echo "<b>Return By:</b> " . $row['borrow_return_date'] . "</p><hr>";
    }
} else {
    echo "<p>No borrowed books found.</p>";
}
