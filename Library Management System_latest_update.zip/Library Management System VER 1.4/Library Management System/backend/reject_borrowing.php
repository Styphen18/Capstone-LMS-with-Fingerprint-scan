<?php
include 'connect.php';
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['borrow_id'])) {
        $userId = intval($_POST['borrow_id']);

        $stmtSelect = $conn->prepare("SELECT borrow_accno FROM borrowrequest_logs WHERE borrow_id = ?");
        $stmtSelect->bind_param("i", $userId);
        $stmtSelect->execute();
        $result = $stmtSelect->get_result();

         if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $acc_no = $row['borrow_accno'];

            // Step 2: Update quantity in the books table
            $stmtUpdate = $conn->prepare("UPDATE booktry SET  bookquantity = bookquantity + 1 WHERE acc_no = ?");
            $stmtUpdate->bind_param("s", $acc_no);
            $stmtUpdate->execute();
            $stmtUpdate->close();
        }
        $stmtSelect->close();
        // Prepare and execute deletion
        $stmt = $conn->prepare("DELETE FROM borrowrequest_logs WHERE borrow_id = ?");
        $stmt->bind_param("i", $userId);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Borrowing request deleted successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to delete borrowing.']);
        }

        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid HTTP method.']);
}

$conn->close();
