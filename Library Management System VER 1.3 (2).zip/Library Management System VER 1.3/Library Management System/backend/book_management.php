<?php
include 'connect.php';

$limit = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1);
$offset = ($page - 1) * $limit;

// Get total records
$totalRes = $conn->query("SELECT COUNT(*) AS total FROM booktry");
$totalRow = $totalRes->fetch_assoc();
$total = $totalRow['total'];
$totalPages = ceil($total / $limit);

// Fetch limited books
$sql = "SELECT * FROM booktry ORDER BY id DESC LIMIT $offset, $limit";
$result = $conn->query($sql);

$rowsHTML = "";
while ($row = $result->fetch_assoc()) {
    $id = htmlspecialchars($row['id']);
    $accNo = htmlspecialchars($row['acc_no']);
    $author = htmlspecialchars($row['bookauthor']);
    $title = htmlspecialchars($row['booktitle']);
    $isbn = htmlspecialchars($row['isbn']);
    $callNo = htmlspecialchars($row['call_no']);
    $classNo = htmlspecialchars($row['class_no']);
    $cutterNo = htmlspecialchars($row['cutter_no']);
    $year = htmlspecialchars($row['bookpublished']);
    $copyNo = htmlspecialchars($row['copy_no']);
    $subject = htmlspecialchars($row['subject_heading']);
    $pages = htmlspecialchars($row['pages']);
    $publisher = htmlspecialchars($row['publisher']);
    $place = htmlspecialchars($row['place_of_publication']);
    $entry = htmlspecialchars($row['bookentry']);

    $rowsHTML .= "
    <tr id='book-row-{$id}'>
    <td>{$id}</td>
        <td>{$accNo}</td>
        <td>{$author}</td>
        <td>{$title}</td>
        <td>{$isbn}</td>
        <td>{$callNo}</td>
        <td>{$classNo}</td>
        <td>{$cutterNo}</td>
        <td>{$year}</td>
        <td>{$copyNo}</td>
        <td>{$subject}</td>
        <td>{$pages}</td>
        <td>{$publisher}</td>
        <td>{$place}</td>
        <td>{$entry}</td>
        <td>
             <a href='#' class='btn btn-primary btn-sm update-btn'
                    data-id='{$id}'
                    data-title=\"{$title}\"
                    data-author=\"{$author}\"
                    data-bookpublished=\"{$year}\"
                    data-accno=\"{$accNo}\"
                    data-isbn=\"{$isbn}\"
                    data-callno=\"{$callNo}\"
                    data-classno=\"{$classNo}\"
                    data-cutterno=\"{$cutterNo}\"
                    data-copyno=\"{$copyNo}\"
                    data-subject=\"{$subject}\"
                    data-pages=\"{$pages}\"
                    data-publisher=\"{$publisher}\"
                    data-place=\"{$place}\"
                    >Update</a>
        </td>
    </tr>";
}

// header('Content-Type: application/json');
echo json_encode([
    'books' => $rowsHTML,
    'totalPages' => $totalPages
]);
