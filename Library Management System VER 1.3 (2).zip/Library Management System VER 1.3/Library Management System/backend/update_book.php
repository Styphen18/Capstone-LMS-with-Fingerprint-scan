<?php
include 'connect.php';
date_default_timezone_set('Asia/Manila');

// Validate required fields
$required_fields = [
    'accNo', 'bookAuthor', 'bookTitle', 'isbn', 'callNo', 'classNo', 'cutterNo',
    'bookpublished', 'bookquantity', 'subject_heading', 'pages', 'publisher', 'place_of_publication'
];

foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        die("Missing field: " . $field);
    }
}

// Escape inputs
$accNo = $_POST['accNo'];
$author = $_POST['bookAuthor'];
$title = $_POST['bookTitle'];
$isbn = $_POST['isbn'];
$callNo = $_POST['callNo'];
$classNo = $_POST['classNo'];
$cutterNo = $_POST['cutterNo'];
$published = $_POST['bookpublished'];
$copyNo = $_POST['bookquantity'];
$subject = $_POST['subject_heading'];
$pages = $_POST['pages'];
$publisher = $_POST['publisher'];
$place = $_POST['place_of_publication'];

// Required: ID for update
$id = $_POST['id'] ?? null;
if (!$id) {
    die("Missing book ID for update.");
}

$sql = "UPDATE booktry 
        SET acc_no=?, bookauthor=?, booktitle=?, isbn=?, call_no=?, class_no=?, cutter_no=?,
            bookpublished=?, copy_no=?, subject_heading=?, pages=?, publisher=?, place_of_publication=?
        WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "sssssssssssssi",
    $accNo, $author, $title, $isbn, $callNo, $classNo, $cutterNo,
    $published, $copyNo, $subject, $pages, $publisher, $place, $id
);

if ($stmt->execute()) {
    echo "Book updated successfully.";
} else {
    echo "Update failed: " . $stmt->error;
}

$stmt->close();
$conn->close();
