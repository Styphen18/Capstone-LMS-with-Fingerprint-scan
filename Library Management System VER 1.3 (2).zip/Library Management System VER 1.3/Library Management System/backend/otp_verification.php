<?php
session_start();
include 'connect.php';
include 'email_sender.php';

$message = ""; // Message placeholder

if (!isset($_SESSION['email'])) {
    header('Location: ../login/signin.html');
    exit();
}

// Create OTP and send it to user email
if (!isset($_SESSION['otp'])) {
    $otp = rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_created_at'] = time();

    $email = $_SESSION['email'];

    $result = sendEmail($email, $otp);
    if ($result === true) {
        $message = "✅ OTP has been sent to your email: $email";
    } else {
        $message = "❌ Error sending OTP: $result";
    }
}

// Verify OTP
if (isset($_POST['verify_otp'])) {
    $entered_otp = $_POST['verify_otp'];
    $otp_expiration_time = time() - ($_SESSION['otp_created_at'] ?? 0);

    if ($otp_expiration_time > 300) {
        unset($_SESSION['otp'], $_SESSION['otp_created_at']);
        $message = "⏰ The OTP code has expired. Please request a new one.";
    } elseif ($entered_otp == $_SESSION['otp']) {
        unset($_SESSION['otp'], $_SESSION['otp_created_at']);
        header('Location: ../pages/homepage01.html');
        exit();
    } else {
        $message = "❌ Incorrect OTP! Please try again.";
    }
}

// Resend OTP
if (isset($_POST['resend_otp'])) {
    $otp = rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['otp_created_at'] = time();

    $email = $_SESSION['email'];
    $result = sendEmail($email, $otp);

    if ($result === true) {
        $message = "✅ A new OTP has been sent to your email: $email";
    } else {
        $message = "❌ Error resending OTP: $result";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../assets/styles/otp.css" />
  <title>OTP Verification</title>
</head>

<body>
<div class="otp-container">
  <h1>Verify OTP</h1>
  <p class="subtext">A 6-digit code has been sent to your email. Please enter it below:</p>

  <!-- Message output -->
  <?php if (!empty($message)): ?>
    <div class="otp-message">
      <?php echo $message; ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="otp_verification.php">
    <label for="verify_otp">OTP Code:</label>
    <input type="number" id="verify_otp" name="verify_otp" placeholder="Enter 6-digit code" required />
    <button id="Verify" type="submit">Verify</button>
  </form>

  <form method="POST" action="otp_verification.php" class="resend-form">
    <button type="submit" name="resend_otp" class="resend-btn">Resend OTP</button>
  </form>
</div>

</body>

</html>


