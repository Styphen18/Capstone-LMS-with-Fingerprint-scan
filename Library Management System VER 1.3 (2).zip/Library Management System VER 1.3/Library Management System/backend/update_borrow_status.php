<?php
include 'connect.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['borrow_id'])) {
    $id = intval($_POST['borrow_id']);

    $stmt = $conn->prepare("UPDATE borrowrequest_logs  SET borrow_status = 'approved' WHERE borrow_id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Request approved.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to approve request.']);
    }

    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}

$conn->close();
