<?php
include '../connect.php';

// Dashboard Total book 
$sql = "SELECT COUNT(*) AS total_user FROM users";
$result = $conn->query($sql);

if ($row = $result->fetch_assoc()) {
    echo $row['total_user'];
} else {
    echo 0;
}
