<?php
include 'connect.php';

header('Content-Type: application/json');


$result = $conn->query("SELECT COUNT(*) AS total FROM report_issue");

if ($result) {
    $row = $result->fetch_assoc();
    echo json_encode(['total' => $row['total']]);
} else {
    echo json_encode(['total' => 0]);
}
