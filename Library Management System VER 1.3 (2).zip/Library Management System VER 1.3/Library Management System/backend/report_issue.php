<?php
include 'connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookId = intval($_POST['book_id']);
    $issueType = trim($_POST['issue_type']);

    // Fetch book info
    $stmt = $conn->prepare("SELECT * FROM borrowrequest_logs WHERE borrow_id = ?");
    $stmt->bind_param("i", $bookId);
    $stmt->execute();
    $result = $stmt->get_result();
    $book = $result->fetch_assoc();

    if ($book) {
        $name = $book['borrow_name'];
        $course = $book['borrow_course'];
        $studentId = $book['borrow_studentid'];
        $bookTitle = $book['borrow_booktitle'];
        $reportedDate = date('Y-m-d H:i:s');

        // Insert to report_issue table
        $insert = $conn->prepare("INSERT INTO report_issue (name, course, student_id, book_title, issue_type, reported_date) VALUES (?, ?, ?, ?, ?, ?)");
        $insert->bind_param("ssssss", $name, $course, $studentId, $bookTitle, $issueType, $reportedDate);
        $insert->execute();

        // Optional: Delete or update original table
        $delete = $conn->prepare("DELETE FROM borrowrequest_logs WHERE borrow_id = ?");
        $delete->bind_param("i", $bookId);
        $delete->execute();

        echo "Issue logged and record removed.";
    } else {
        echo "Book not found.";
    }
}
