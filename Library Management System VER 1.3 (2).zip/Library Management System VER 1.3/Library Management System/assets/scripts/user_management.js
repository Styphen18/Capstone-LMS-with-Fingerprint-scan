// ======================================================================= get and show user account with pagination
// take user data from the server (acc_crud.php) and updates the user table.
function loadUsers(page = 1) {
  fetch(`../backend/acc_crud.php?page=${page}`) 
    .then(response => response.json())
    .then(data => {
      document.getElementById('userTableBody').innerHTML = data.users;
      setupUserPagination(data.totalPages, page);
    })
    .catch(error => {
      document.getElementById('userTableBody').innerHTML = "Error loading user list.";
      console.error("Error loading acc_crud.php:", error);
    });
}

// ======================================================================= Setup Pagination for User List
// Dynamically generates pagination buttons based on total number of pages.
// Highlights the current page and attaches click events to load corresponding user data
function setupUserPagination(totalPages, currentPage) {
  const pagination = document.getElementById('userpagination');
  pagination.innerHTML = '';

  for (let i = 1; i <= totalPages; i++) {
    const li = document.createElement('li');
    li.classList.add('page-item');
    if (i === currentPage) li.classList.add('active');

    const a = document.createElement('a');
    a.classList.add('page-link');
    a.href = '#';
    a.textContent = i;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      loadUsers(i);
    });

    li.appendChild(a);
    pagination.appendChild(li);
  }
}

// ======================================================================= get user value and put it in admin   
function submitAddAccount(event) {
  event.preventDefault();

  const fullname = document.getElementById('fullname').value.trim();
  const yrcourse = document.getElementById('yrcourse').value.trim();
  const studentid = document.getElementById('studentid').value.trim();
  const contact = document.getElementById('contact').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();

  if (!fullname || !yrcourse || !studentid || !contact || !email || !password) {
    alert("Please fill in all required fields.");
    return;
  }

  fetch('../backend/acc_crud.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 
      'fullname=' + encodeURIComponent(fullname) +
      '&yrcourse=' + encodeURIComponent(yrcourse) +
      '&studentid=' + encodeURIComponent(studentid) +
      '&contact=' + encodeURIComponent(contact) +
      '&email=' + encodeURIComponent(email) +
      '&password=' + encodeURIComponent(password)
  })
  .then(response => response.text())
  .then(data => {
    console.log(data);
    closeUserModal();
    document.getElementById("accForm").reset();
    showPanel('users');
  })
  .catch(error => {
    alert("Error: " + error);
  });
}
// ============================================================================ MODAL FOR USER // NOT WORKING CURRENTLY
function openUpdateModaluser(id, name, department, studentId, contact, email) {
  document.getElementById('userId').value = id;
  document.getElementById('fullname').value = name;
  document.getElementById('yrcourse').value = department;
  document.getElementById('studentid').value = studentId;
  document.getElementById('contact').value = contact;
  document.getElementById('email').value = email;
  document.getElementById('password').value = ""; // always empty

  document.querySelector('#userModal h2').textContent = "Update Account";
  document.querySelector('#accForm button[type="submit"]').textContent = "Update";
  document.getElementById('accForm').onsubmit = submitUpdateAccount;

  document.getElementById('userModal').style.display = "flex";
}
// ============================================================================ UPDATE ACCOUNT // NOT WORKING CURRENTLY
function submitUpdateAccount(event) {
  event.preventDefault();

  const id = document.getElementById('userId').value;
  const fullname = document.getElementById('fullname').value.trim();
  const yrcourse = document.getElementById('yrcourse').value.trim();
  const studentid = document.getElementById('studentid').value.trim();
  const contact = document.getElementById('contact').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();

  const body = 
    'id=' + encodeURIComponent(id) +
    '&fullname=' + encodeURIComponent(fullname) +
    '&yrcourse=' + encodeURIComponent(yrcourse) +
    '&studentid=' + encodeURIComponent(studentid) +
    '&contact=' + encodeURIComponent(contact) +
    '&email=' + encodeURIComponent(email) +
    '&password=' + encodeURIComponent(password);

  fetch('../backend/acc_crud.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body
  })
  .then(response => response.text())
  .then(data => {
    console.log(data);
    closeUserModal();
    document.getElementById("accForm").reset();
    showPanel('users');
  })
  .catch(error => alert("Error: " + error));
}

document.addEventListener('click', function (e) {
  if (e.target.classList.contains('update-btn-user')) {
    e.preventDefault();

    const btn = e.target;
    openUpdateModaluser(
  btn.dataset.id,
  btn.dataset.name,
  btn.dataset.department,
  btn.dataset.student_id,
  btn.dataset.contact,
  btn.dataset.email
);
  }
});

function openUserModal() {
  document.getElementById('accForm').reset();
  document.getElementById('userId').value = "";

  document.querySelector('#userModal h2').textContent = "Add Account";
  document.querySelector('#accForm button[type="submit"]').textContent = "Add";
  document.getElementById('accForm').onsubmit = submitAddAccount;

  document.getElementById("userModal").style.display = "flex";
}

function closeUserModal() {
  document.getElementById('userModal').style.display = "none";
  document.getElementById('accForm').reset();
  document.getElementById('userId').value = "";
  document.getElementById('accForm').onsubmit = submitAddAccount;
}

// ============================================================================ Delete user function
function deleteUser(userId) {
  const dialog = document.getElementById('userdialog');
  dialog.style.display = 'block';

  const yesBtn = document.getElementById('users-yes');
  const noBtn = document.getElementById('users-no');

  // Clear previous event listeners
  yesBtn.onclick = null;
  noBtn.onclick = null;

  yesBtn.onclick = (e) => {
    e.preventDefault();
    dialog.style.display = 'none';

    // Keep the original PHP call from second function
    fetch('../backend/delete_account.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `action=delete&id=${encodeURIComponent(userId)}`
    })
    .then(response => response.json())
    .then(data => {
      alert(data.message);
      if (data.status === 'success') {
        loadUsers(); // Call to refresh the user list
      }
    })
    .catch(error => {
      alert("Error deleting user.");
      console.error("Delete error:", error);
    });
  };

  noBtn.onclick = () => {
    dialog.style.display = 'none';
  };
}
