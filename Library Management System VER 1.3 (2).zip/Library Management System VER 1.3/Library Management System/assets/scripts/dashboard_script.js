// =============================================== DASHBOARD 
function getbooktotal() {
  fetch('../backend/dashboard/total_book.php')
    .then(response => response.text())
    .then(total => {
      document.querySelector('.num_books').textContent = total;
    })
    .catch(error => {
      document.querySelector('.num_books').textContent = "Error loading";
      console.error("Fetch error:", error);
    });
}

function gettotalbook_pending() {
  fetch('../backend/dashboard/total_book_pending.php')
    .then(response => response.text())
    .then(pending => {
      document.querySelector('.num_request').textContent = pending;
    })
    .catch(error => {
      document.querySelector('.num_request').textContent = "Error loading";
      console.error("Fetch error:", error);
    });
}

function gettotalbook_approved() {
  fetch('../backend/dashboard/total_book_approved.php')
    .then(response => response.text())
    .then(approved => {
      document.querySelector('.num_approved').textContent = approved;
    })
    .catch(error => {
      document.querySelector('.num_approved').textContent = "Error loading";
      console.error("Fetch error:", error);
    });
}

function gettotal_users() {
  fetch('../backend/dashboard/total_user.php')
    .then(response => response.text())
    .then(users => {
      document.querySelector('.num_user').textContent = users;
    })
    .catch(error => {
      document.querySelector('.num_user').textContent = "Error loading";
      console.error("Fetch error:", error);
    });
}
function gettotalbook_borrowed() {
  fetch('../backend/dashboard/total_borrowed.php')
    .then(response => response.text())
    .then(total_borrowed => {
      document.querySelector('.total_borrowed').textContent = total_borrowed;
    })
    .catch(error => {
      document.querySelector('.total_borrowed').textContent = "Error loading";
      console.error("Fetch error:", error);
    });
}

 function piechart() {
  fetch('../backend/get_piechart.php')
    .then(res => res.json())
    .then(data => {
      const ctx = document.getElementById('bookStatusChart').getContext('2d');
      new Chart(ctx, {
        type: 'pie',
        data: {
          labels: ['Returned', 'Unreturned', 'Issue'],
          datasets: [{
            data: [data.returned, data.unreturned, data.issue],
            backgroundColor: ['#4CAF50', '#FFC107', '#F44336'],
            hoverOffset: 10
          }]
        },
        options: {
          responsive: true,
          plugins: {
            title: {
              display: true,
              text: 'Books by Status'
            }
          }
        }
      });
    })
    .catch(err => console.error('Chart data fetch error:', err));
}
window.addEventListener('DOMContentLoaded', piechart);
// =========================================== end of dashboard

window.onload = function() {
  getbooktotal();
  gettotalbook_pending();
  gettotalbook_approved();
  gettotal_users();
  gettotalbook_borrowed();
  piechart();
};
