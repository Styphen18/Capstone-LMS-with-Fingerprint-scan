// ---------------- Voice Search ------------ 
function startVoiceSearch() {
    let recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';

    recognition.onresult = function(event) {
        let voicetypequery = event.results[0][0].transcript;
        
        document.getElementById('result').innerText = "Searching for: " + voicetypequery;
        fetchBooks(voicetypequery);
    };
    recognition.start();
}

function fetchBooks(voicetypequery) {
    fetch(`../backend/search.php?GETvoicesearch=${voicetypequery}`)
    .then(response => response.json())
    .then(data => {
        let bookList = document.getElementById("bookList");
        bookList.innerHTML = "";
        
        if (data.length > 0) {
            data.forEach(book => {
                let li = document.createElement("li");
                li.textContent = `${book.title} by ${book.author} [${book.category}] ${book.pub_year}`;

                const borrowBtn  = document.createElement("button");
                borrowBtn.textContent = "Borrow";
                borrowBtn.dataset.title = book.title;

                borrowBtn.addEventListener("click", () => {
                    handleBorrowClick(book.title);
                });
                li.appendChild(borrowBtn);
                bookList.appendChild(li);
                });

        } else {
            bookList.innerHTML = "<li>No books found</li>";
        }
    })
    .catch(error => console.error("Error:", error));
}

// -------- Text Search -------------
function textsearch() {
    const textsearchquery = document.getElementById("textsearch").value;  
    if (textsearchquery.trim() !== "") {
        fetchtextsearch(textsearchquery);    
    } else {
        document.getElementById("result").innerText = "Please enter a search term!";
    }
}

function fetchtextsearch(textsearchquery) {
    fetch(`../backend/search.php?GETtextsearch=${textsearchquery}`)
        .then(response => response.json())
        .then(fulltextbooks => {
            let textsearch_result = document.getElementById('textbookList');
            textsearch_result.innerHTML = ""; // Clear previous results

            if (fulltextbooks.length > 0) {
                fulltextbooks.forEach(textbook => {
                    const list = document.createElement('li');
                    list.textContent = `${textbook.text_title} by ${textbook.text_author} [${textbook.text_genre}] ${textbook.text_pubyear}`;

                    const borrowBtn = document.createElement("button");
                    borrowBtn.textContent = "Borrow";
                    borrowBtn.dataset.title = textbook.text_title;

                    borrowBtn.addEventListener("click", () => {
                        handleBorrowClick(textbook.text_title);
                    });
                    list.appendChild(borrowBtn);
                    textsearch_result.appendChild(list);
                });
                
            } else {
                textsearch_result.innerHTML = "<li>No books found</li>";
            }
        })
        .catch(error => {
            console.error("Error:", error);
        });
}

// -------------- Borrow Handler -------------- 
function handleBorrowClick(selectedTitle) {
    fetch("../backend/get_booktitle.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `selected_book_title=${encodeURIComponent(selectedTitle)}`
    })
    .then(() => {
        return fetch("../backend/check_session.php");
    })
    .then(response => response.json())
    .then(data => {
        if (data.logged_in) {
            window.location.href = "../pages/book_borrow.html";
        } else {
            window.location.href = "../login/signin.html";
        }
    })
    .catch(error => {
        console.error("Borrow flow failed:", error);
        alert("Something went wrong.");
    });
}