
<?php
session_start();
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] == 'admin') {
  header("Location: ../pages/homepage01.html");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Admin page</title>

  <link rel="stylesheet" href="../assets/styles/admin_test.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="../assets/scripts/showfunctionscript.js"></script>
  <script src="../assets/scripts/user_management.js"></script>
  <script src="../assets/scripts/borrowing_management_script.js"></script>
  <script src="../assets/scripts/book_return_management_script.js"></script>
  <script src="../assets/scripts/book_logs_management_script.js"></script>
 


</head>

<body>
  <div class="header">
    <h1>STI COLLEGE ROSARIO LIBRARY</h1>
  </div>
  <!-- Sidepanel btn -->
  <div class="container_adminpanel">
    <div class="sidebar">
      <button id="Dashboard_btn" class="active-btn" onclick="showPanel('dashboard')">
        <i class="bi bi-pie-chart-fill" style="color: #ffffff"></i> Dashboard </button>

      <button id="Borrow-btn" onclick="showPanel('borrowPanel')">
        <i class="bi bi-journal-plus" style="color: #ffffff;"></i> Borrowing Management </button>

      <button id="Return_btn" onclick="showPanel('returnPanel')">
        <i class="bi bi-journal-minus" style="color: #ffffff"></i>Book Return</button>

      <button id="Employee_btn" onclick="showPanel('employee')">
        <i class="bi bi-person-fill-gear" style="color: #ffffff"></i>Account Management </button>

      <button id="Books_btn" onclick="showPanel('books')">
        <i class="bi bi-journal" style="color: #ffffff"></i>Book Management</button>

      <button id="logs-btn" onclick="showPanel('logsPanel')">
        <i class="bi bi-journal-bookmark-fill" style="color: #ffffff;">Book Logs </i>
      </button>
      <button id="Del-btn" onclick="showPanel('DeleteBook')">
        <i class="bi bi-journal-bookmark-fill" style="color: #ffffff;">Book Deleted </i>
      </button>
    </div>
    <!-- ================================================================== Dashboard content, mostly -->
    <div class="mainpanel">
      <div id="dashboard" class="panel active">
        <br>
        <div class="dashboard_border">
          <!-- boook-->
          <div class="border-total">
            <div>
              <span class="num_books" style="font-size: 2rem; font-weight: bold;"></span><br>
              TOTAL BOOKS
            </div>
            <i class="bi bi-journals" style="font-size: 4rem;"></i>
          </div>
          <!-- user-->
          <div class="border-user">
            <div>
              <span class="num_user" style="font-size: 2rem; font-weight: bold;"></span><br>
              TOTAL USERS
            </div>
            <i class="bi bi-journal-check" style="font-size: 4rem;"></i>
          </div>
          <!-- pending-->
          <div class="border-borrow">
            <div>
              <span class="num_request" style="font-size: 2rem; font-weight: bold;"></span><br>
              PENDING REQUEST BOOKS
            </div>
            <i class="bi bi-journal-arrow-down" style="font-size: 4rem;"></i>
          </div>
          <!-- approved-->
          <div class="border-approve">
            <div>
              <span class="num_approved" style="font-size: 2rem; font-weight: bold;"></span><br>
              APPROVED REQUEST BOOKS
            </div>
            <i class="bi bi-journal-check" style="font-size: 4rem;"></i>
          </div>
            <br>
          
        </div>
        <br>
          <div class="dashboard_2nd">
                <div id="chartContainer">
                  <canvas id="bookStatusChart"></canvas>
                </div>
                
                <div class="border-total_borrowed">
            <div>
              <span class="num_approved" style="font-size: 2rem; font-weight: bold;"></span><br>
              total_borrowed
            </div>
            <i class="bi bi-journal-check" style="font-size: 4rem;"></i>
          </div>
          </div>

      </div>

      <!-- ================================================================= Side bars Content // Borrow Management-->
      <div id="borrowPanel" class="panel">
        <br>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">YearCourse/Department</th>
              <th scope="col">Student/Faculty ID</th>
              <th scope="col">Contact no.</th>
              <th scope="col">Email</th>
              <th scope="col">Book Title</th>
              <th scope="col">Book Borrow Date</th>
              <th scope="col">Book return date</th>
              <th scope="col">Status</th>
              <th scope="col">ACTIONS</th>
            </tr>
          </thead>
          <tbody id="borrowTableBody" class="table-group-divider">
          </tbody>
        </table>

        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-end" id="borrowPagination">
          </ul>
        </nav>
      </div>
      <!-- ===================================================== Account Management -->
      <div id="employee" class="panel">
        <br>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">YearCourse/Department</th>
              <th scope="col">Student/Faculty ID</th>
              <th scope="col">Contact no.</th>
              <th scope="col">Role</th>
              <th scope="col">Email</th>
              <th scope="col">ACTIONS</th>
            </tr>
          </thead>
          <tbody id="userTableBody" class="table-group-divider">
          </tbody>
        </table>

        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-end" id="userpagination">
          </ul>
        </nav>
      </div>
      <!-- ===================================================== Book logs -->
      <div id="logsPanel" class="panel">
        <br>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">YearCourse/Department</th>
              <th scope="col">Student/Faculty ID</th>
              <th scope="col">Contact no.</th>
              <th scope="col">Email</th>
              <th scope="col">Book Title</th>
              <th scope="col">Book Borrow Date</th>
              <th scope="col">Book return date</th>
              <th scope="col">Status</th>
              <th scope="col">ACTIONS</th>
            </tr>
          </thead>
          <tbody id="borrowTableBody_logs" class="table-group-divider">
          </tbody>
        </table>

        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-end" id="borrowPagination_logs">
          </ul>
        </nav>
      </div>
      <!-- ===================================================== Book Return -->
      <div id="returnPanel" class="panel">
        <br>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">YearCourse/Department</th>
              <th scope="col">Student/Faculty ID</th>
              <th scope="col">Contact no.</th>
              <th scope="col">Email</th>
              <th scope="col">Book Title</th>
              <th scope="col">Book Borrow Date</th>
              <th scope="col">Book return date</th>
              <th scope="col">Status</th>
              <th scope="col">ACTIONS</th>
            </tr>
          </thead>
          <tbody id="borrowTableBody_return" class="table-group-divider">
          </tbody>
        </table>

        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-end" id="borrowPagination_return">
          </ul>
        </nav>
      </div>
      <!-- ===================================================== Book Management -->
      <div id="books" class="panel">
        <button id="Add_book" onclick="openModal()">
          <i class="bi bi-plus-circle-fill"></i> AddBook </button>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">BookTitle</th>
              <th scope="col">BookAuthor</th>
              <th scope="col">YearPublished</th>
              <th scope="col">Quantity</th>
              <th scope="col">GENRE</th>
              <th scope="col">BookEntry</th>
              <th scope="col">ACTIONS</th>
            </tr>
          </thead>
          <tbody id="bookTableBody" class="table-group-divider">
          </tbody>
        </table>

        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-end" id="bookpagination">
            <!-- Pagination buttons will be inserted dynamically -->
          </ul>
        </nav>
      </div>
       <!-- ===================================================== Deletion -->
     <div id="DeleteBook" class="panel">
      <br>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Borrower Name</th>
            <th scope="col">Course / Department</th>
            <th scope="col">Student / Faculty ID</th>
            <th scope="col">Book Title</th>
            <th scope="col">Issue Type</th> <!-- Changed label for clarity -->
            <th scope="col">Reported Date</th> <!-- Optional: to track when it was reported -->
          </tr>
        </thead>

          <tbody id="book_deletion" class="table-group-divider">
          </tbody>
        </table>

        <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-end" id="borrowPagination_return">
          </ul>
        </nav>
      </div>
    </div>
 
  </div>

  <!-- ===================================================== Book Management // Update book Modal  -->
  <div id="myModal" class="modal">
    <div class="modal-content">
      <label class="close" onclick="closeModal()"><i class="bi bi-x-square-fill"></i></label>
      <h2>Add a New Book</h2>
      <form id="addBookForm" onsubmit="submitBookForm(event)">
        <div class="form-floating">
          <input type="text" class="form-control" id="bookTitle" placeholder="BookTitle">
          <label for="bookTitle">BookTitle</label>
        </div>
        <div class="form-floating">
          <input type="text" class="form-control" id="bookAuthor" placeholder="BookAuthor">
          <label for="bookAuthor">BookAuthor</label>
        </div>
        <div class="form-floating">
          <input type="text" class="form-control" id="bookpublished" placeholder="bookpublished">
          <label for="bookpublished">bookpublished</label>
        </div>
        <div class="form-floating">
          <input type="number" class="form-control" id="quantity" placeholder="Quantity">
          <label for="quantity">Quantity</label>
        </div>
        <div class="form-floating">
          <input type="text" class="form-control" id="genre" placeholder="Genre">
          <label for="genre">Genre</label>
        </div>
        <input type="hidden" id="bookId" name="bookId">

        <div id="addbutton"><button type="submit">Add</button></div>
      </form>
    </div>
  </div>
  <!-- ===================================================== Account management Modal  -->
  <div id="userModal" style="display: none;">
    <form id="accForm">
      <h2>Update Account</h2>
      <input type="hidden" id="userId" name="id">
      <input type="text" id="fullname" name="fullname" placeholder="Full Name" required>
      <input type="text" id="yrcourse" name="yrcourse" placeholder="Year & Course" required>
      <input type="text" id="studentid" name="studentid" placeholder="Student ID" required>
      <input type="text" id="contact" name="contact" placeholder="Contact" required>
      <input type="email" id="email" name="email" placeholder="Email" required>
      <input type="password" id="password" name="password" placeholder="New Password (optional)">
      <button type="submit">Update</button>
    </form>
  </div>


      <div class="dialog-delete">
        <!--for delete books-->
          <div id="confirmDialog" class="custom-dialog">
            <div class="dialog-box">
              <label class="close-delete" onclick="closeDialog()"><i class="bi bi-x"></i></label>
              <p>Are you sure you want to delete this book?</p>
              <div class="form-floating mb-3">
                 <div class="form-group">
                    <select class="form-control" required id="details" style="height: 50px">
                      <option value="" disabled selected>Select an option</option>
                      <option value="damage">Damage</option>
                      <option value="lose">Lose</option>
                      <option value="replace">Replace</option>
                    </select>
                  </div>
              </div>
                <button id="confirmYes" class="btn-confirm">Yes</button>
                <button id="confirmNo" class="btn-cancel">No</button>
            </div>
      </div>

<!--for delete users-->
    <div id="userdialog" class="user-dialog">
          <div class="user-dialog-box">
            <p>Are you sure you want to delete this account?</p>
            <button id="users-yes" class="user-btn-yes">Yes</button>
            <button id="users-no" class="user-btn-cancel">No</button>
          </div>
    </div>
  </div>


</body>

</html>