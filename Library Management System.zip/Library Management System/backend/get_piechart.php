<?php
include 'connect.php';
header('Content-Type: application/json');

// Returned
$returned = $conn->query("SELECT COUNT(*) AS total FROM borrowrequest_logs WHERE borrow_status = 'returned'")
    ->fetch_assoc()['total'];

// Unreturned
$unreturned = $conn->query("SELECT COUNT(*) AS total FROM borrowrequest_logs WHERE borrow_status = 'approved'")
    ->fetch_assoc()['total'];

// Issue (damage, lost, replace — stored in report_issue table)
$issue = $conn->query("SELECT COUNT(*) AS total FROM report_issue")
    ->fetch_assoc()['total'];

echo json_encode([
    'returned' => (int)$returned,
    'unreturned' => (int)$unreturned,
    'issue' => (int)$issue
]);