<?php
session_start();
include 'connect.php';
include 'email_sender.php';

// Send data to database -- TABLE NAME: Borrowrequest_logs
if (isset($_POST['form-borrowbtn'])) {
    $email = $_SESSION['email'];
    $user_type = $_SESSION['user_type'];
    $user_id = $_SESSION['user_id'];
    $user_name = $_POST['form-name'];
    $user_course = $_POST['form-yearandcourse'];
    $user_number = $_POST['form-studentid'];
    $user_contactnum = $_POST['form-contact'];
    $borrow_booktitle = $_POST['form-booktitle'];
    $borrow_time = $_POST['form-borrowbookdate'];
    $borrow_return = $_POST['form-bookreturn'];

    $check_quantity = "SELECT bookquantity FROM booktry WHERE booktitle = '$borrow_booktitle'";
    $result = $conn->query($check_quantity);

    if ($result && $result->num_rows >= 1) {
        $row = $result->fetch_assoc();
        $quantity = $row['bookquantity'];

        if ($quantity >= 2) {

            // Check if user have 2 book pending // This also make the book into pending after borrowing
            $check_pending = "SELECT COUNT(*) AS pending_count FROM borrowrequest_logs WHERE borrow_user_id = '$user_id' AND (borrow_status = 'pending' OR borrow_status = 'approved')";
            $pending_result = $conn->query($check_pending);
            $pending_row = $pending_result->fetch_assoc();
            $borrower_book_count = $pending_row['borrower_book_count'] ?? 0;

            if ($user_type == "student" && $pending_row['pending_count'] >= 2) {
                header("Location: ../pages/homepage01.html?borrow=error_pending_limit");
                exit();
            } else if ($user_type == "teacher" && $pending_row['pending_count'] >= 3) {
                header("Location: ../pages/homepage01.html?borrow=error_pending_limit");
                exit();
            }

            // Insert All Borrower information inside database for logs
            $post_borrow_details = "INSERT INTO borrowrequest_logs (borrow_user_id, borrow_name, borrow_course, borrow_studentid, borrow_contact, borrow_booktitle, borrow_date, borrow_return_date, borrow_status)
                                    VALUES ('$user_id', '$user_name', '$user_course', '$user_number', '$user_contactnum', '$borrow_booktitle', '$borrow_time', '$borrow_return', 'pending')";
            $borrower_details = $conn->query($post_borrow_details);

            // Minus quantity
            $update_quantity = "UPDATE booktry SET bookquantity = bookquantity - 1 WHERE booktitle = '$borrow_booktitle'";
            $conn->query($update_quantity);

            if ($borrower_details) {
                // Successful book request
                header("Location: ../pages/homepage01.html?borrow=successful");
                sendEmail_for_borrower($email, $user_name, $user_number, $user_course, $user_contactnum, $borrow_booktitle, $borrow_time, $borrow_return);
                exit();
            } else {
                // You still have pending return books
                header("Location: ../pages/homepage01.html?borrow=unsuccessful");
                exit();
            }
        } else {
            // Quantity is 1 // Should be 2 or more
            header("Location: ../pages/homepage01.html?borrow=error_quantity_low");
            exit();
        }
    } else {
        // Book not found
        header("Location: ../pages/homepage01.html?borrow=error_no_book_found");
        exit();
    }
}



// Get data from database for/to auto fill ng form
if (isset($_SESSION['user_id']) && isset($_SESSION['book_title'])) {
    $user_id = $_SESSION['user_id'];
    $book_title = $_SESSION['book_title'];

    $get_userdata = "SELECT fullname, yrcourse, studentid, contact FROM users WHERE id = $user_id";
    $result = $conn->query($get_userdata);
    $user_data = $result->fetch_assoc();

    $get_booktitle = "SELECT booktitle FROM booktry WHERE booktitle = '$book_title'";
    $result_book = $conn->query($get_booktitle);
    $book_data = $result_book->fetch_assoc();

    $formitems = [
        'user' => $user_data,
        'book' => $book_data
    ];
    echo json_encode($formitems);
}
