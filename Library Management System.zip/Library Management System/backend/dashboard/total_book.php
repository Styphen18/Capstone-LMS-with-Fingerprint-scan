<?php
include '../connect.php';

// Dashboard Total book 
$sql = "SELECT SUM(bookquantity) AS total FROM booktry";
$result = $conn->query($sql);

if ($row = $result->fetch_assoc()) {
    echo $row['total'];
} else {
    echo 0;
}
