<?php
session_start();
include 'connect.php';

$response = [];

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    $user_query = "SELECT fullname, yrcourse, studentid, contact, email FROM users WHERE id = $user_id";
    $result = $conn->query($user_query);

    if ($result && $result->num_rows > 0) {
        $response['user'] = $result->fetch_assoc();
    }
}

if (isset($_SESSION['book_title']) && isset($_SESSION['acc_no']) && isset($_SESSION['call_no'])) {
    $book_title = $_SESSION['book_title'];
    $book_accno = $_SESSION['acc_no'];
    $book_callno = $_SESSION['call_no'];
    $book_query = "SELECT booktitle, acc_no, call_no FROM booktry WHERE booktitle = '$book_title' AND acc_no = '$book_accno' LIMIT 1";

    $result_book = $conn->query($book_query);

    if ($result_book && $result_book->num_rows > 0) {
        $response['book'] = $result_book->fetch_assoc();
    }
}
echo json_encode($response);
