<?php
include '../connect.php';

// Pending Dashboard count
$sql = "SELECT COUNT(*) AS total_approved FROM borrowrequest_logs WHERE borrow_status = 'approved'";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    echo $row['total_approved'];
} else {
    echo 0;
}
