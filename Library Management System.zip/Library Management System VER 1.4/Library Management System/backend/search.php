<?php
session_start();
include("connect.php");

// VOICE SEARCH JSON
if (isset($_GET['GETvoicesearch'])) {
    $voicetypequery = $conn->real_escape_string($_GET['GETvoicesearch']);

    $keywords = explode(" ", $voicetypequery);

    // Build dynamic SQL conditions
    $conditions = [];
    foreach ($keywords as $word) {
        $safeWord = $conn->real_escape_string($word);
        $conditions[] = "
            (booktitle LIKE '%$safeWord%' 
            OR acc_no LIKE '%$safeWord%' 
            OR bookauthor LIKE '%$safeWord%' 
            OR subject_heading LIKE '%$safeWord%' 
            OR bookpublished LIKE '%$safeWord%')
        ";
    }

    $whereClause = implode(" OR ", $conditions);
    $sql = "SELECT * FROM booktry WHERE $whereClause";
    $result = $conn->query($sql);

    $books = [];
    while ($row = $result->fetch_assoc()) {
        $books[] = [
            'call_no' => $row['call_no'],
            'acc_no' => $row['acc_no'],
            'title' => $row['booktitle'],
            'author' => $row['bookauthor'],
            'subject' => $row['subject_heading'],
            'pub_year' => $row['bookpublished']
        ];
    }

    echo json_encode($books);
}


//TEXT SEARCH JSON
if (isset($_GET['GETtextsearch'])) {
    $textsearchquery = $_GET['GETtextsearch'];
    // Break the search input into words
    $text_search = explode(" ", $textsearchquery);
    $text_search_array = [];

    foreach ($text_search as $word) {
        $text_search_querystatement = $conn->real_escape_string($word);

        // Build the WHERE conditions for each word
        $text_search_array[] = "
            (booktitle LIKE '%$text_search_querystatement%' 
            OR acc_no LIKE '%$text_search_querystatement%' 
            OR bookauthor LIKE '%$text_search_querystatement%' 
            OR subject_heading LIKE '%$text_search_querystatement%' 
            OR bookpublished LIKE '%$text_search_querystatement%')
        ";
    }

    // Combine all the OR conditions
    $whereClause = implode(" OR ", $text_search_array);

    // Final SQL query
    $sql = "SELECT * FROM booktry WHERE $whereClause";
    $result = $conn->query($sql);

    $textbooklist = [];
    while ($row = $result->fetch_assoc()) {
        $textbooklist[] = [
            'text_callno' => $row['call_no'],
            'text_accno' => $row['acc_no'],
            'text_title' => $row['booktitle'],
            'text_author' => $row['bookauthor'],
            'text_subject' => $row['subject_heading'],
            'text_pubyear' => $row['bookpublished']
        ];
    }

    echo json_encode($textbooklist); // Send as JSON
}


$conn->close();
