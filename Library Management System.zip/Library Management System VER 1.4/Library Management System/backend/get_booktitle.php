<?php
include 'connect.php';
session_start();
if (isset($_POST['selected_book_title']) && isset($_POST['selected_book_accno']) && isset($_POST['selected_book_callno'])) {
    $_SESSION['book_title'] = $_POST['selected_book_title'];
    $_SESSION['acc_no'] = $_POST['selected_book_accno'];
    $_SESSION['call_no'] = $_POST['selected_book_callno'];
    echo "Book title stored in session";
} else {
    echo "No title received";
}
