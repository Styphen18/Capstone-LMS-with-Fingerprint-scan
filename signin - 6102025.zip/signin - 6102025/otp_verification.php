<?php
include 'connect.php';

session_start();

// Check if the user is logged in and has already reached this page
if (!isset($_SESSION['email'])) {
    header('Location: ../login/signin.html');
    exit();
}

// If OTP is not set, generate and send OTP
if (!isset($_SESSION['otp'])) {
    $otp = rand(100000, 999999);  // Generate a random 6-digit OTP
    $_SESSION['otp'] = $otp; // Store OTP in session

    // Send OTP email using PHP mail function or a more reliable email service like PHPMailer or SMTP
    $email = $_SESSION['email'];  // Get email from session
    mail($email, "Your OTP Code", "Your OTP code is: $otp"); // You can improve the headers
    echo "OTP has been sent to your email!";
}

// Verify OTP if form is submitted
if (isset($_POST['verify_otp'])) {
    $entered_otp = $_POST['verify_otp'];

    // Check if entered OTP matches the one stored in the session
    if ($entered_otp == $_SESSION['otp']) {
        // OTP is correct, redirect to homepage
        header('Location: ../pages/homepage01.html');
        exit();
    } else {
        // OTP is incorrect
        echo "Incorrect OTP! Please try again.";
    }
}
?>
