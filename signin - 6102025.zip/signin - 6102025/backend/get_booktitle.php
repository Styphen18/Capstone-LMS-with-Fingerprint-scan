<?php
include 'connect.php';
session_start();
if (isset($_POST['selected_book_title'])) {
    $_SESSION['book_title'] = $_POST['selected_book_title'];
    echo "Book title stored in session";
} else {
    echo "No title received";
}
?>
