<?php
include 'connect.php';

if (isset($_GET["id"])) {
    $id = $_GET["id"];

    // First, check the current quantity
    $checkStmt = $conn->prepare("SELECT bookquantity FROM booktry WHERE id = ?");
    $checkStmt->bind_param("i", $id);
    $checkStmt->execute();
    $checkStmt->bind_result($quantity);
    $checkStmt->fetch();
    $checkStmt->close();

    if ($quantity > 1) {
        // If quantity is more than 1, subtract 1
        $updateStmt = $conn->prepare("UPDATE booktry SET bookquantity = bookquantity - 1 WHERE id = ?");
        $updateStmt->bind_param("i", $id);
        if ($updateStmt->execute()) {
            echo "1 copy removed from book (Remaining: " . ($quantity - 1) . ")";
        } else {
            echo "Failed to update quantity: " . $updateStmt->error;
        }
        $updateStmt->close();
    } else {
        // If quantity is 1 or less, delete the book
        $deleteStmt = $conn->prepare("DELETE FROM booktry WHERE id = ?");
        $deleteStmt->bind_param("i", $id);
        if ($deleteStmt->execute()) {
            echo "Book deleted as quantity was 1.";
        } else {
            echo "Delete failed: " . $deleteStmt->error;
        }
        $deleteStmt->close();
    }

    $conn->close();
} else {
    echo "No ID provided.";
}
?>