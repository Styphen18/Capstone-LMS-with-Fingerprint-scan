<?php
include 'connect.php';

$id = $_POST['id'];
$title = $_POST['bookTitle'];
$author = $_POST['bookAuthor'];
$published = $_POST['bookpublished'];
$quantity = $_POST['bookquantity'];
$genre = $_POST['genre'];

$sql = "UPDATE booktry SET booktitle=?, bookauthor=?, bookpublished=?, bookquantity=?, genre=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssisi", $title, $author, $published, $quantity, $genre, $id);

if ($stmt->execute()) {
    echo "Book updated successfully.";
} else {
    echo "Update failed: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>