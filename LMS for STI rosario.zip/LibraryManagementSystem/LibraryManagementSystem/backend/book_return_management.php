<?php
session_start();
include 'connect.php';
header('Content-Type: application/json; charset=UTF-8');

function safeAttr($value)
{
    return htmlspecialchars(trim(str_replace(["\n", "\r"], '', $value)), ENT_QUOTES);
}

// Pagination variables
$limit = 10; // Items per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1); // Prevent negative or zero page
$offset = ($page - 1) * $limit;

$totalQuery = $conn->query("SELECT COUNT(*) AS total_borrower FROM borrowrequest_logs WHERE borrow_status = 'approved'");
$totalRow = $totalQuery->fetch_assoc();
$totalUser = $totalRow['total_borrower'];
$totalPages = ceil($totalUser / $limit);

// Fetch paginated user
$sql = "SELECT * FROM borrowrequest_logs WHERE borrow_status = 'approved' AND borrow_status != 'returned' ORDER BY borrow_id DESC LIMIT $offset, $limit";
$result = $conn->query($sql);

// Build user row
$userRows = "";
while ($row = $result->fetch_assoc()) {

    $borrow_id_return  = $row['borrow_id'];
    $borrow_accno_return  = $row['borrow_accno'];
    $borrow_callno_return  = $row['borrow_callno'];
    $name_borrower_return = safeAttr($row['borrow_name']);
    $course_department_borrower_return = safeAttr($row['borrow_course']);
    $student_faculty_id_borrower_return = safeAttr($row['borrow_studentid']);
    $contact_borrower_return = safeAttr($row['borrow_contact']);
    $borrower_mail_return = safeAttr($row['borrow_email']);
    $book_title_return = safeAttr($row['borrow_booktitle']);
    $book_borrow_date_return = safeAttr($row['borrow_date']);
    $book_return_date_return = safeAttr($row['borrow_return_date']);
    $borrow_status_return = safeAttr($row['borrow_status']);

    $userRows .= "
    <tr id='user-row-{$borrow_id_return}'>
    <td>{$borrow_id_return}</td>
    <td>{$borrow_accno_return}</td>
    <td>{$borrow_callno_return}</td>
    <td>{$name_borrower_return}</td>
    <td>{$course_department_borrower_return}</td>
    <td>{$student_faculty_id_borrower_return}</td>
    <td>{$contact_borrower_return}</td>
    <td>{$borrower_mail_return}</td>
    <td>{$book_title_return}</td>
    <td>{$book_borrow_date_return}</td>
    <td>{$book_return_date_return}</td>
    <td>{$borrow_status_return}</td>
    <td>
        <a href='#' class='btn btn-primary btn-sm' onclick='update_to_returned({$borrow_id_return})'>Return</a>
        <a href='#' class='btn btn-danger btn-sm' onclick='deleteBook(\"{$borrow_id_return}\")'>Remove</a>
    </td>
</tr>";
}

// Return JSON
echo json_encode([
    'borrows_return' => $userRows,
    'totalPages' => $totalPages
]);
