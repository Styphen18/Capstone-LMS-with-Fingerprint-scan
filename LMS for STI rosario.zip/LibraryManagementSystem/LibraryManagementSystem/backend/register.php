<?php
session_start();
include 'connect.php';


// SIGN UP 
if (isset($_POST['signUp'])) {
    $firstname = $_POST['firstname'] ?? '';
    $lastname = $_POST['lastname'] ?? '';
    $mi = $_POST['mi'] ?? '';
    $fullname = trim($firstname . ' ' . ($mi ? $mi . ' ' : '') . $lastname);

    $course_department = $_POST['floatingcourse_department'] ?? '';
    $user_type = $_POST['floatingusertype'] ?? '';
    $studentid = $_POST['floatingstudentid'] ?? '';
    $contact = $_POST['floatingcontact'] ?? '';
    $email = $_POST['floatingInput'] ?? '';
    $password = $_POST['floatingpassword'] ?? '';

    // PASSWORD HASH
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // CHECK EMAIL IF EXIST
    $checkemail = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($checkemail);

    if ($result->num_rows > 0) {
        echo "Email Address already exists!";
    } else {
        $insertQuery = "INSERT INTO users (fullname, yrcourse, usertype, studentid, contact, email, password) 
                        VALUES ('$fullname', '$course_department', '$user_type', '$studentid', '$contact', '$email', '$hashedPassword')";

        if ($conn->query($insertQuery) === TRUE) {
            header("Location: ../login/signin.html");
        } else {
            echo "Error: " . $conn->error;
        }
    }
}

// LOG IN
if (isset($_POST['signIn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $check_user = "SELECT * FROM users WHERE email='$email'";
    $result_checkuser = $conn->query($check_user);

    if ($result_checkuser->num_rows > 0) {
        // session_start();
        $user_cred = $result_checkuser->fetch_assoc();
        if (password_verify($password, $user_cred['password'])) {
            $_SESSION['email'] = $user_cred['email'];                // Retrieving an email (name of user) gagamitin to get user name or admin 
            $_SESSION['user_id'] = $user_cred['id'];
            $_SESSION['role'] = $user_cred['role'];
            $_SESSION['user_type'] = $user_cred['usertype'];

            if ($email === 'blackveil1122@gmail.com') {
                header("Location: ../pages/homepage01.php");
                exit();
            }
            if ($user_cred['role'] === 'admin') {
                header("Location: ../admin/admin.php");
                exit();
            } else {
                header("Location: otp_verification.php");            // Change this after connecting to OTP html 
                exit();
            }
        } else {
            echo "Incorrect Input Please try again.";
        }
    } else {
        echo "User not found!";
    }
}
