<?php
// Always use absolute path
$exe = "C:\\Users\\Jhanlee\\Downloads\\Fingerprint-Scanner-Registration-main\\Fingerprint-Scanner-Registration-main\\FingerprintTest\\bin\\Debug\\FingerprintTest.exe";

if (file_exists($exe)) {
    // Run the EXE (non-blocking process)
    exec("start \"\" \"$exe\"");
} else {
    echo "File not found: $exe";
}
