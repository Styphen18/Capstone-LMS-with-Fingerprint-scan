<?php
// Always use absolute path
$timein_csharpexe = "C:\\Users\\Jhanlee\\Downloads\\Fingerprint-Scanner-Matching-main\\Fingerprint-Scanner-Matching-main\\Printmyname\\bin\\Debug\\Printmyname.exe";

if (file_exists($timein_csharpexe)) {
    // Run the EXE (non-blocking process)
    exec("start \"\" \"$timein_csharpexe\"");
} else {
    echo "File not found: $timein_csharpexe";
}
