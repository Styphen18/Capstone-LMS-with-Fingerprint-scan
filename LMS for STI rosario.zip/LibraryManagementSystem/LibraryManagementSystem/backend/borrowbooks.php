<?php
session_start();
include 'connect.php';
include __DIR__ . '/Email_sender/email_sender.php';

// Send data to database -- TABLE NAME: Borrowrequest_logs
if (isset($_POST['form-borrowbtn'])) {
    $borrow_accno = $_POST['form-accno'];
    $borrow_callno = $_POST['form-callno'];
    $email = $_POST['form-email'];
    $user_type = $_SESSION['user_type'];
    $user_id = $_SESSION['user_id'];
    $user_name = $_POST['form-name'];
    $user_course = $_POST['form-yearandcourse'];
    $user_number = $_POST['form-studentid'];
    $user_contactnum = $_POST['form-contact'];
    $borrow_booktitle = $_POST['form-booktitle'];
    $borrow_time = $_POST['form-borrowbookdate'];
    $borrow_return = $_POST['form-bookreturn'];


    // select quantity of asc no that has been picked (clicked by button)
    $check_quantity = "SELECT bookquantity FROM booktry WHERE acc_no = '$borrow_accno'";
    $result = $conn->query($check_quantity);
    $row = $result->fetch_assoc();
    $quantity = $row['bookquantity'];

    if ($quantity >= 1) {
        // Check if user have 2 book pending // This also make the book into pending after borrowing
        $check_pending = "SELECT COUNT(*) AS pending_count FROM borrowrequest_logs WHERE borrow_user_id = '$user_id' AND (borrow_status = 'pending' OR borrow_status = 'approved')";
        $pending_result = $conn->query($check_pending);
        $pending_row = $pending_result->fetch_assoc();
        $pending_count = $pending_row['pending_count'] ?? 0;


        if (($user_type == "Student" && $pending_count >= 2) || ($user_type == "Teacher" && $pending_count >= 3)) {
            header("Location: ../pages/homepage01.php?borrow=error_pending_limit");
            exit();
        }

        // Insert All Borrower information inside database for logs
        $post_borrow_details = "INSERT INTO borrowrequest_logs (borrow_user_id, borrow_accno, borrow_callno, borrow_name, borrow_course, borrow_studentid, borrow_contact, borrow_booktitle, borrow_email, borrow_date, borrow_return_date, borrow_status)
                                    VALUES ('$user_id', '$borrow_accno', '$borrow_callno', '$user_name', '$user_course', '$user_number', '$user_contactnum', '$borrow_booktitle', '$email', '$borrow_time', '$borrow_return', 'pending')";
        $borrower_details = $conn->query($post_borrow_details);

        if ($borrower_details) {
            // Successful book request
            $update_quantity = "UPDATE booktry SET bookquantity = bookquantity - 1 WHERE acc_no = '$borrow_accno' AND bookquantity > 0 ";
            $conn->query($update_quantity);
            if ($conn->affected_rows > 0) {
                header("Location: ../pages/homepage01.php?borrow=successful");
                sendEmail_for_borrower($email, $user_name, $user_number, $user_course, $user_contactnum, $borrow_booktitle, $borrow_time, $borrow_return);
                exit();
            } else {
                header("Location: ../pages/homepage01.php?borrow=unsuccessful");
                exit();
            }
        } else {
            // You still have pending return books
            header("Location: ../pages/homepage01.php?borrow=unsuccessful");
            exit();
        }
    } else {
        // Quantity is 1 // Should be 2 or more
        header("Location: ../pages/homepage01.php?borrow=error_quantity_low");
        exit();
    }
} else {
    // Book not found
    header("Location: ../pages/homepage01.php?borrow=error_no_book_found");
    exit();
}
