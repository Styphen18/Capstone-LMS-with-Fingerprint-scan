<?php
include 'connect.php';
header('Content-Type: application/json; charset=UTF-8');

function safeAttr($value)
{
    return htmlspecialchars(trim(str_replace(["\n", "\r"], '', $value)), ENT_QUOTES);
}

// Initialize
$userRows = "";
$totalPages = 1; // Default fallback

// ========== HANDLE FORM SUBMISSIONS ========== //
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $_POST['fullname'] ?? '';
    $yrcourse = $_POST['yrcourse'] ?? '';
    $studentid = $_POST['studentid'] ?? '';
    $contact = $_POST['contact'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // ========== UPDATE ==========
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET fullname=?, yrcourse=?, studentid=?, contact=?, email=?, password=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssi", $fullname, $yrcourse, $studentid, $contact, $email, $hashedPassword, $id);
        } else {
            $sql = "UPDATE users SET fullname=?, yrcourse=?, studentid=?, contact=?, email=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssi", $fullname, $yrcourse, $studentid, $contact, $email, $id);
        }

        if ($stmt->execute()) {
            echo json_encode(['message' => "Update successful"]);
        } else {
            echo json_encode(['error' => "Update failed: " . $conn->error]);
        }

        $stmt->close();
        $conn->close();
        exit;
    }

    // ========== INSERT NEW USER ==========
    if (!empty($fullname) && !empty($studentid) && !empty($email) && !empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $role = 'user'; // default role or customize as needed
        $sql = "INSERT INTO users (fullname, yrcourse, studentid, contact, email, password, role)
                VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssss", $fullname, $yrcourse, $studentid, $contact, $email, $hashedPassword, $role);

        if ($stmt->execute()) {
            echo json_encode(['message' => "Account created successfully"]);
        } else {
            echo json_encode(['error' => "Insert failed: " . $conn->error]);
        }

        $stmt->close();
        $conn->close();
        exit;
    }

    // If we reached here, required fields were missing
    echo json_encode(['error' => "Missing required fields"]);
    exit;
}

// ========== FETCH USERS FOR DISPLAY ========== //
$limit = 10;
$page = isset($_GET['page']) ? max((int)$_GET['page'], 1) : 1;
$offset = ($page - 1) * $limit;

// Count total users
$totalQuery = $conn->query("SELECT COUNT(*) AS total FROM users");
$totalRow = $totalQuery->fetch_assoc();
$totalUser = $totalRow['total'];
$totalPages = ceil($totalUser / $limit);

// Fetch paginated users
$sql = "SELECT * FROM users ORDER BY id DESC LIMIT $offset, $limit";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $name = safeAttr($row['fullname']);
    $course_department = safeAttr($row['yrcourse']);
    $student_faculty_id = safeAttr($row['studentid']);
    $contact = safeAttr($row['contact']);
    $role = safeAttr($row['role']);
    $email = safeAttr($row['email']);
    $pass = safeAttr($row['password']);

    $userRows .= "
    <tr id='user-row-{$id}'>
        <td>{$id}</td>
        <td>{$name}</td>
        <td>{$course_department}</td>
        <td>{$student_faculty_id}</td>
        <td>{$contact}</td>
        <td>{$role}</td>
        <td>{$email}</td>
        <td>
            <a href='#' class='btn btn-primary btn-sm update-btn-user'
               data-id='{$id}'
               data-name=\"{$name}\"
               data-department=\"{$course_department}\"
               data-student_id=\"{$student_faculty_id}\"
               data-contact=\"{$contact}\"
               data-email=\"{$email}\"
               data-pass=\"\">
              Update
            </a>
            <a href='#' class='btn btn-danger btn-sm' onclick='deleteUser({$id})'>Delete</a>
        </td>
    </tr>";
}

// Return final JSON for frontend
echo json_encode([
    'users' => $userRows,
    'totalPages' => $totalPages
]);
