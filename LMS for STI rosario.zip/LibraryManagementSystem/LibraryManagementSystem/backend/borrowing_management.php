<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include 'connect.php';
header('Content-Type: application/json; charset=UTF-8');

function safeAttr($value)
{
    return htmlspecialchars(trim(str_replace(["\n", "\r"], '', $value)), ENT_QUOTES);
}

// Pagination variables
$limit = 10; // Items per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1); // Prevent negative or zero page
$offset = ($page - 1) * $limit;

$totalQuery = $conn->query("SELECT COUNT(*) AS total_borrower FROM borrowrequest_logs");
$totalRow = $totalQuery->fetch_assoc();
$totalUser = $totalRow['total_borrower'];
$totalPages = ceil($totalUser / $limit);

// Fetch paginated user
$sql = "SELECT * FROM borrowrequest_logs WHERE borrow_status != 'approved' AND borrow_status != 'returned' ORDER BY borrow_id DESC LIMIT $offset, $limit";
$result = $conn->query($sql);

// Build user row
$userRows = "";
while ($row = $result->fetch_assoc()) {
    $borrow_id  = $row['borrow_id'];

    $acc_no_borrower = safeAttr($row['borrow_accno']);
    // $copy_no_borrower = safeAttr($row['borrow_copyno']);
    $call_no_borrower = safeAttr($row['borrow_callno']);

    $name_borrower = safeAttr($row['borrow_name']);
    $course_department_borrower = safeAttr($row['borrow_course']);
    $student_faculty_id_borrower = safeAttr($row['borrow_studentid']);
    $contact_borrower = safeAttr($row['borrow_contact']);
    $borrower_mail = safeAttr($row['borrow_email']);
    $book_title = safeAttr($row['borrow_booktitle']);
    $book_borrow_date = safeAttr($row['borrow_date']);
    $book_return_date = safeAttr($row['borrow_return_date']);
    $borrow_status = safeAttr($row['borrow_status']);

    $userRows .= "
    <tr id='user-row-{$borrow_id}'>
        <td>{$borrow_id}</td>
        <td>{$acc_no_borrower}</td>
        <td>{$call_no_borrower}</td>
        <td>{$name_borrower}</td>
        <td>{$course_department_borrower}</td>
        <td>{$student_faculty_id_borrower}</td>
        <td>{$contact_borrower}</td>
        <td>{$borrower_mail}</td>
        <td>{$book_title}</td>
        <td>{$book_borrow_date}</td>
        <td>{$book_return_date}</td>
        <td>{$borrow_status}</td>
       
        <td>
            <a href='#' class='btn btn-primary btn-sm update-btn-borrow' onclick='updateBorrowStatus({$borrow_id})'
               data-id='{$borrow_id}'
               data-name=\"{$name_borrower}\"
               data-department=\"{$course_department_borrower}\"
               data-student_id=\"{$student_faculty_id_borrower}\"
               data-contact=\"{$contact_borrower}\"
               data-email=\"{$borrower_mail}\"
               data-booktitle=\"{$book_title}\"
               data-bookborrowdate=\"{$book_borrow_date}\"
               data-bookreturndate=\"{$book_return_date}\"

              > Accept </a>
            <a href='#' class='btn btn-danger btn-sm' onclick='deleteBorrowLog({$borrow_id})'> Reject </a>
        </td>
    </tr>
    ";
}

// Return JSON
echo json_encode([
    'borrows' => $userRows,
    'totalPages' => $totalPages
]);
