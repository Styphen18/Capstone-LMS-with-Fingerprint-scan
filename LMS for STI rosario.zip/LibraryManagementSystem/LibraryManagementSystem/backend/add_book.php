<?php
include 'connect.php';
date_default_timezone_set('Asia/Manila');

// Validate required fields
$required_fields = ['accNo', 'bookAuthor', 'bookTitle', 'isbn', 'bookpublished', 'copy_no', 'pages', 'publisher', 'place_of_publication'];

foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        die("Missing field: " . $field);
    }
}

// Assign and sanitize form inputs
$accNo = $_POST['accNo'];
$author = $_POST['bookAuthor'];
$title = $_POST['bookTitle'];
$isbn = $_POST['isbn'];
$callNo = $_POST['callNo'] ?? '';
$classNo = $_POST['classNo'] ?? '';
$cutterNo = $_POST['cutterNo'] ?? '';
$published = $_POST['bookpublished'];
$copyNo = $_POST['copy_no'];
$subject = $_POST['subject_heading'] ?? '';
$pages = $_POST['pages'];
$publisher = $_POST['publisher'];
$place = $_POST['place_of_publication'];

// Check for duplicate acc_no
$sql_check = "SELECT acc_no FROM booktry WHERE acc_no = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("s", $accNo);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    echo "A book with Accession No. $accNo already exists.";
    $stmt_check->close();
    $conn->close();
    exit;
}
$stmt_check->close();

// Insert the book into the database
$sql = "INSERT INTO booktry (
    acc_no, bookauthor, booktitle, isbn, call_no, class_no, cutter_no,
    bookpublished, copy_no, subject_heading, pages,
    publisher, place_of_publication
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param(
    "sssssssssssss",
    $accNo, $author, $title, $isbn, $callNo, $classNo, $cutterNo,
    $published, $copyNo, $subject, $pages,
    $publisher, $place
);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "Insert failed: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
