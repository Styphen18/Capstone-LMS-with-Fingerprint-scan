<?php
include '../connect.php';

header('Content-Type: application/json');

$result = $conn->query("SELECT COUNT(*) AS total_borrowed FROM borrowrequest_logs");

if ($result) {
    $row = $result->fetch_assoc();
    echo $row['total_borrowed'];
} else {
    echo json_encode(['total_borrowed' => 0]);
}
