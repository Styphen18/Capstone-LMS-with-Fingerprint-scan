<?php
require '../vendor/autoload.php';

// require_once '../PHPmailer/PHPMailer.php';
// require_once '../PHPmailer/SMTP.php';
// require_once '../PHPmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// OTP Email
function sendEmail($email, $otp)
{
    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'noreply.lms.test@gmail.com';
        $mail->Password = 'kzjc wcnf tgdz vkry'; // Gmail App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;


        //Sender
        $mail->setFrom('noreply.lms.test@gmail.com', 'STI College Rosario Library System');
        $mail->addAddress($email);

        // ONLY for local dev (disable in live server)
        // $mail->SMTPOptions = [
        //     'ssl' => [
        //         'verify_peer' => false,
        //         'verify_peer_name' => false,
        //         'allow_self_signed' => true
        //     ]
        // ];

        // Email for OTP
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body = "Your OTP code is: <b>$otp</b>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        return "Mailer Error: {$mail->ErrorInfo}";
    }
}

// Email for Borrowing 
function sendEmail_for_borrower($email, $user_name, $user_number, $user_course, $user_contactnum, $borrow_booktitle, $borrow_time, $borrow_return)
{
    $mail_for_borrower = new PHPMailer(true);

    try {
        $mail_for_borrower->isSMTP();
        $mail_for_borrower->Host = 'smtp.gmail.com';
        $mail_for_borrower->SMTPAuth = true;
        $mail_for_borrower->Username = 'noreply.lms.test@gmail.com';
        $mail_for_borrower->Password = 'kzjc wcnf tgdz vkry'; // Gmail App Password
        $mail_for_borrower->SMTPSecure = 'tls';
        $mail_for_borrower->Port = 587;

        //Sender
        $mail_for_borrower->setFrom('noreply.lms.test@gmail.com', 'STI College Rosario Library System');
        $mail_for_borrower->addAddress($email);

        // ONLY for local dev (disable in live server)
        $mail_for_borrower->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];

        // Email for OTP
        $mail_for_borrower->isHTML(true);
        $mail_for_borrower->Subject = 'Borrowing Details';
        $mail_for_borrower->Body = "
        <div style='font-family: Arial, sans-serif; padding: 20px; color: #333;'>
        <h2 style='color: #2c3e50;'>Library Borrowing Confirmation</h2>
        <p>Dear <strong>$user_name</strong>,</p>

        <p>Thank you for borrowing from the STI College Rosario Library. Below are the details of your transaction:</p>

        <table cellpadding='8' cellspacing='0' border='0' style='border-collapse: collapse; margin-top: 10px;'>
            <tr><td><strong>Name:</strong></td><td>$user_name</td></tr>
            <tr><td><strong>Student/Faculty ID:</strong></td><td>$user_number</td></tr>
            <tr><td><strong>Course/Department:</strong></td><td>$user_course</td></tr>
            <tr><td><strong>Contact Number:</strong></td><td>$user_contactnum</td></tr>
            <tr><td><strong>Book Title:</strong></td><td>$borrow_booktitle</td></tr>
            <tr><td><strong>Date Borrowed:</strong></td><td>$borrow_time</td></tr>
            <tr><td><strong>Return Due Date:</strong></td><td><b>$borrow_return</b></td></tr>
        </table>

        <p style='margin-top: 15px;'>Please present this email to the librarian when claiming your book.</p>
        <p><strong>Reminder:</strong> Books must be returned on or before <b>$borrow_return</b>. A late fee of <strong>₱5.00 per day</strong> will apply for overdue returns.</p>

        <p style='margin-top: 25px;'>
            Sincerely,<br>
            <strong>Library Services</strong><br>
            STI College Rosario
        </p>

        <hr style='margin-top: 30px;'>
        <p style='font-size: 12px; color: #888;'>This is an automated message. Please do not reply to this email.</p>
        </div>
        ";
        $mail_for_borrower->send();
        return true;
    } catch (Exception $e) {
        return "Mailer Error: {$mail_for_borrower->ErrorInfo}";
    }
}

//  Email for Returned books
function sendEmail_for_borrower_returned($email, $user_name, $user_number, $user_course, $user_contactnum, $bookTitle, $borrow_time, $borrow_return)
{
    $mail_for_returnedbooks = new PHPMailer(true);
    try {
        $mail_for_returnedbooks->isSMTP();
        $mail_for_returnedbooks->Host = 'smtp.gmail.com';
        $mail_for_returnedbooks->SMTPAuth = true;
        $mail_for_returnedbooks->Username = 'noreply.lms.test@gmail.com';
        $mail_for_returnedbooks->Password = 'kzjc wcnf tgdz vkry'; // Gmail App Password
        $mail_for_returnedbooks->SMTPSecure = 'tls';
        $mail_for_returnedbooks->Port = 587;

        //Sender
        $mail_for_returnedbooks->setFrom('noreply.lms.test@gmail.com', 'STI College Rosario Library System');
        $mail_for_returnedbooks->addAddress($email);

        // ONLY for local dev (disable in live server)
        $mail_for_returnedbooks->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];

        // Email for OTP
        $mail_for_returnedbooks->isHTML(true);
        $mail_for_returnedbooks->Subject = 'Book Return Confirmation - STI Library';

        $mail_for_returnedbooks->Body = "
            <div style='font-family: Arial, sans-serif; padding: 20px; color: #333;'>
                <h2 style='color: #2c3e50;'>Book Return Confirmation</h2>
                <p>Dear <strong>$user_name</strong>,</p>

                <p>We would like to confirm that the following book has been successfully returned to the STI College Rosario Library:</p>

                <table cellpadding='8' cellspacing='0' border='0' style='border-collapse: collapse; margin-top: 10px;'>
                    <tr><td><strong>Name:</strong></td><td>$user_name</td></tr>
                    <tr><td><strong>Student/Faculty ID:</strong></td><td>$user_number</td></tr>
                    <tr><td><strong>Course/Department:</strong></td><td>$user_course</td></tr>
                    <tr><td><strong>Contact Number:</strong></td><td>$user_contactnum</td></tr>
                    <tr><td><strong>Book Title:</strong></td><td>$bookTitle</td></tr>
                    <tr><td><strong>Date Borrowed:</strong></td><td>$borrow_time</td></tr>
                    <tr><td><strong>Date Returned:</strong></td><td><b>$borrow_return</b></td></tr>
                </table>

                <p style='margin-top: 15px;'>Thank you for returning the book on time. We appreciate your continued cooperation in maintaining the library’s resources.</p>

                <p>If you have any questions, feel free to contact the library support team.</p>

                <p style='margin-top: 25px;'>
                    Sincerely,<br>
                    <strong>Library Services</strong><br>
                    STI College Rosario
                </p>

                <hr style='margin-top: 30px;'>
                <p style='font-size: 12px; color: #888;'>This is an automated message. Please do not reply to this email.</p>
            </div>
        ";
        $mail_for_returnedbooks->send();
    } catch (Exception $e) {
        return "Mailer Error: {$mail_for_returnedbooks->ErrorInfo}";
    }
}
