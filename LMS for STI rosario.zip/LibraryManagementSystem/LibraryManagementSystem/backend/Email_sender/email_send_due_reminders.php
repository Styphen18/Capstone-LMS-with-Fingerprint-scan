<?php
// SECURITY KEY
$secret_key = "MySecret123";
if (!isset($_GET['key']) || $_GET['key'] !== $secret_key) {
    http_response_code(403);
    die("ACCESS DENIED");
}

require '../vendor/autoload.php';
include 'connect.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//  TODAY'S DATE
$today = date("Y-m-d");
// FIND OVER DUE BOOKS
$query_overdue = "SELECT * FROM borrowrequest_logs WHERE borrow_return_date < '$today' AND borrow_status IN ('pending', 'approved')";
$result_overdue = $conn->query($query_overdue);

//  FIND BOOKS DUE TODAY
$query = "SELECT * FROM borrowrequest_logs WHERE borrow_return_date = '$today' AND borrow_status IN ('pending', 'approved')";
$result = $conn->query($query);

if ($result->num_rows == 0) {
    echo "No due books today.";
    exit();
}


//  SEND EMAIL REMINDERS
while ($row = $result->fetch_assoc()) {

    $email = $row['borrow_email'];
    $name = $row['borrow_name'];
    $book = $row['borrow_booktitle'];
    $due = $row['borrow_return_date'];

    $mail = new PHPMailer(true);

    try {
        // SMTP SETTINGS (same as your OTP + borrow email)
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'noreply.lms.test@gmail.com';
        $mail->Password = 'kzjc wcnf tgdz vkry';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // SENDER
        $mail->setFrom('noreply.lms.test@gmail.com', 'STI College Rosario Library System');
        $mail->addAddress($email);

        // LOCAL DEV ONLY — turn off on hosting
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];

        // EMAIL CONTENT
        $mail->isHTML(true);
        $mail->Subject = "📚 Reminder: Your Book is Due Today ($due)";

        $mail->Body = "
            <div style='font-family: Arial; padding: 20px;'>
                <h2 style='color:#c0392b;'>Book Due Reminder</h2>
                <p>Hello <strong>$name</strong>,</p>

                <p>This is a reminder that the book you borrowed:</p>

                <p><strong>$book</strong></p>

                <p>is <strong>DUE TODAY ($due)</strong>.</p>

                <p>Please return it to the library to avoid late fees.</p>

                <p style='margin-top: 20px;'>Thank you,<br>STI College Rosario Library</p>
                <hr>
                <p style='font-size: 12px; color: #888;'>This is an automated email. Do not reply.</p>
            </div>
        ";

        $mail->send();
        echo "Reminder sent to $email<br>";
    } catch (Exception $e) {
        echo "Failed to send email to $email — {$mail->ErrorInfo}<br>";
    }
}

while ($row_overdue = $result_overdue->fetch_assoc()) {

    $overdue_email = $row_overdue['borrow_email'];
    $overdue_name = $row_overdue['borrow_name'];
    $overdue_book = $row_overdue['borrow_booktitle'];
    $overdue_due = $row_overdue['borrow_return_date'];

    // Days late calculation
    $due_timestamp = strtotime($overdue_due);
    $today_timestamp = strtotime($today);
    $days_late = floor(($today_timestamp - $due_timestamp) / 86400); // 1 day = 86400s

    $fine = $days_late * 5;

    $overdue_mail = new PHPMailer(true);

    try {
        // SMTP SETTINGS (same as your OTP + borrow email)
        $overdue_mail->isSMTP();
        $overdue_mail->Host = 'smtp.gmail.com';
        $overdue_mail->SMTPAuth = true;
        $overdue_mail->Username = 'noreply.lms.test@gmail.com';
        $overdue_mail->Password = 'kzjc wcnf tgdz vkry';
        $overdue_mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $overdue_mail->Port = 587;

        // SENDER
        $overdue_mail->setFrom('noreply.lms.test@gmail.com', 'STI College Rosario Library System');
        $overdue_mail->addAddress($overdue_email);

        // LOCAL DEV ONLY — turn off on hosting
        $overdue_mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];

        // EMAIL CONTENT
        $overdue_mail->isHTML(true);
        $overdue_mail->Subject = "⚠️ Overdue Notice: Your Book is Late by $days_late Day(s)";

        $overdue_mail->Body = "
            <div style='font-family: Arial; padding: 20px; color: #333;'>
                <h2 style='color:#e74c3c;'>📚 Overdue Book Alert</h2>

                <p>Hello <strong>$overdue_name</strong>,</p>

                <p>The book you borrowed:</p>
                <p><strong>$overdue_book</strong></p>

                <p>was due on <strong>$overdue_due</strong> and is now 
                <strong>$days_late day(s)</strong> overdue.</p>

                <p>A late fee of <strong>₱5.00 per day</strong> applies.</p>

                <h3 style='color:#c0392b;'>Total Fine: ₱$fine.00</h3>

                <p>Please return the book as soon as possible to avoid additional fees.</p>

                <p style='margin-top: 20px;'>
                    Thank you,<br>
                    STI College Rosario Library
                </p>

                <hr>
                <p style='font-size: 12px; color: #888;'>
                    This is an automated email. Do not reply.
                </p>
            </div>
        ";

        $overdue_mail->send();
    } catch (Exception $e) {
        echo "Failed to send email to $overdue_email — {$mail->ErrorInfo}<br>";
    }
}
