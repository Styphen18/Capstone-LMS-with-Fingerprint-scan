<?php
include 'connect.php';
header('Content-Type: application/json; charset=UTF-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

$date = isset($_GET['date']) ? $_GET['date'] : null;
$todaydate = date('Y-m-d');

if ($date) {
    $stmt = $conn->prepare("SELECT studentid, fullname, course, timein, timeout FROM attendance WHERE date = ? ORDER BY timein DESC");
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT studentid, fullname, course, timein, timeout FROM attendance WHERE date = '$todaydate' ORDER BY timein DESC");
}

$attendanceData = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $attendanceData[] = $row;
    }
}
echo json_encode($attendanceData);
$conn->close();
exit;
