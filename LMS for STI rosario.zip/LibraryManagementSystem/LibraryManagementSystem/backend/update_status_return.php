<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'connect.php';
include __DIR__ . '/Email_sender/email_sender.php';
session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['borrow_id'])) {
    $id = intval($_POST['borrow_id']);

    // Step 1: Get the book title from borrowrequest_logs
    // $stmt = $conn->prepare("SELECT borrow_booktitle FROM borrowrequest_logs WHERE borrow_id = ?");
    // $stmt->bind_param("i", $id);
    // $stmt->execute();
    // $stmt->bind_result($bookTitle);
    // if (!$stmt->fetch()) {
    $stmt = $conn->prepare("SELECT borrow_booktitle, borrow_date, borrow_return_date, borrow_name, borrow_studentid, borrow_course, borrow_contact, borrow_email FROM borrowrequest_logs WHERE borrow_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($bookTitle, $borrow_time, $borrow_return, $user_name, $user_number, $user_course, $user_contactnum, $email);
    if (!$stmt->fetch()) {
        echo json_encode(['status' => 'error', 'message' => 'Borrow record not found.']);
        $stmt->close();
        $conn->close();
        exit;
    }
    $stmt->close();

    // Step 2: Update the borrow status
    $update = $conn->prepare("UPDATE borrowrequest_logs SET borrow_status = 'returned' WHERE borrow_id = ?");
    $update->bind_param("i", $id);
    if (!$update->execute()) {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update return status.']);
        $update->close();
        $conn->close();
        exit;
    }
    $update->close();

    // Step 3: Increase the quantity of the book in booktry
    $updateQty = $conn->prepare("UPDATE booktry SET bookquantity = bookquantity + 1 WHERE booktitle = ?");
    $updateQty->bind_param("s", $bookTitle);
    if ($updateQty->execute()) {
        sendEmail_for_borrower_returned($email, $user_name, $user_number, $user_course, $user_contactnum, $bookTitle, $borrow_time, $borrow_return);
        echo json_encode(['status' => 'success', 'message' => 'Book returned and quantity updated.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Book returned, but failed to update quantity.']);
    }
    $updateQty->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}

$conn->close();
