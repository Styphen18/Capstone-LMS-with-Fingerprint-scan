<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
file_put_contents("debug_log.txt", file_get_contents("php://input"));
// Read the JSON input
$input = json_decode(file_get_contents("php://input"), true);

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo "This API works only with POST requests.";
    exit;
}

if (!$input || !isset($input["userId"])) {
    echo "Waiting for fingerprint input...";
    exit;
}

$userId = intval($input["userId"]);

// TODO: Do whatever you want with the user ID
// Example: update attendance or login session
file_put_contents("latest_fingerprint.txt", $userId);

// Respond back
echo json_encode([
    "status" => "success",
    "receivedId" => $userId
]);
