function bookmanagement_search() {
    let searchValue = document.getElementById("bookmanagement_search").value.toLowerCase();
    let table = document.getElementById("bookTableBody");
    let rows = table.getElementsByTagName("tr");

    for (let i = 0; i < rows.length; i++) {
        let cells = rows[i].getElementsByTagName("td");
        let found = false;

        // Check all table columns in a row
        for (let j = 0; j < cells.length; j++) {
            if (cells[j].textContent.toLowerCase().includes(searchValue)) {
                found = true;
                break;
            }
        }

        // Show/hide row
        rows[i].style.display = found ? "" : "none";
    }
}

document.getElementById("bookmanagement_search").addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
        bookmanagement_search();
    }
});
