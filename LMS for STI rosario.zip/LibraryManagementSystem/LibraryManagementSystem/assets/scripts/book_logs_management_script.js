// ======================================================================= get and show borrowing logs with pagination
function loadBorrowingLogs_logs(page = 1) {
  fetch(`../backend/book_logs_management.php?page=${page}`)
    .then(response => response.json())
    .then(data => {
      document.getElementById('borrowTableBody_logs').innerHTML = data.borrows_logs;
      setupBorrowPagination_logs(data.totalPages, page);
    })
    .catch(error => {
      document.getElementById('borrowTableBody_logs').innerHTML = "Error loading borrowing list.";
      console.error("Error loading book_logs_management.php:", error);
    });
}


// ======================================================================= Setup Pagination for Borrowing Logs
function setupBorrowPagination_logs(totalPages, currentPage) {
  const pagination = document.getElementById('borrowPagination_logs');
  pagination.innerHTML = '';

  const prevLi = document.createElement('li');
  prevLi.classList.add('page-item');
  if (currentPage === 1) prevLi.classList.add('disabled');

  const prevA = document.createElement('a');
  prevA.classList.add('page-link');
  prevA.href = '#';
  prevA.textContent = 'Previous';
  prevA.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentPage > 1) {
      currentPage--;
      loadBooks(currentPage);
    }
  });

  prevLi.appendChild(prevA);
  pagination.appendChild(prevLi);

  let start = Math.max(currentPage - 1, 1);
  let end = Math.min(start + 2, totalPages);

  start = Math.max(end - 2 ,1);

  // Page numbers
 for (let i = start; i <= end; i++) {
    const li = document.createElement('li');
    li.className = `page-item ${i === currentPage ? 'active' : ''}`;

    const a = document.createElement('a');
    a.classList.add('page-link');
    a.href = '#';
    a.textContent = i;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      currentPage = i;
      loadBooks(currentPage);
    });

    li.appendChild(a);
    pagination.appendChild(li);
  }

  // Next button
  const nextLi = document.createElement('li');
  nextLi.classList.add('page-item');
  if (currentPage === totalPages) nextLi.classList.add('disabled');

  const nextA = document.createElement('a');
  nextA.classList.add('page-link');
  nextA.href = '#';
  nextA.textContent = 'Next';

  nextA.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentPage < totalPages) loadBorrowingLogs_logs(currentPage + 1);
  });

  nextLi.appendChild(nextA);
  pagination.appendChild(nextLi);
}
