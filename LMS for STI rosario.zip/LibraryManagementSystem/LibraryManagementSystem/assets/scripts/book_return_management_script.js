// ======================================================================= get and show borrowing logs with pagination
function loadBorrowingLogs_return(page = 1) {
  fetch(`../backend/book_return_management.php?page=${page}`)
    .then(response => response.json())
    .then(data => {
      document.getElementById('borrowTableBody_return').innerHTML = data.borrows_return;
      setupBorrowPagination_return(data.totalPages, page);
    })
    .catch(error => {
      document.getElementById('borrowTableBody_return').innerHTML = "Error loading borrowing list.";
      console.error("Error loading book_return_management.php:", error);
    });
}

// ======================================================================= Setup Pagination for Borrowing Logs

function setupBorrowPagination_return(totalPages, currentPage) {
  const pagination = document.getElementById('borrowPagination_return');
  pagination.innerHTML = '';

  const prevLi = document.createElement('li');
  prevLi.classList.add('page-item');
  if (currentPage === 1) prevLi.classList.add('disabled');

  const prevA = document.createElement('a');
  prevA.classList.add('page-link');
  prevA.href = '#';
  prevA.textContent = 'Previous';
  prevA.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentPage > 1) {
      currentPage--;
      loadBorrowingLogs_return(currentPage);
    }
  });

  prevLi.appendChild(prevA);
  pagination.appendChild(prevLi);

  let start = Math.max(currentPage - 1, 1);
  let end = Math.min(start + 2, totalPages);

  start = Math.max(end - 2 ,1);

  // Page numbers
 for (let i = start; i <= end; i++) {
    const li = document.createElement('li');
    li.className = `page-item ${i === currentPage ? 'active' : ''}`;

    const a = document.createElement('a');
    a.classList.add('page-link');
    a.href = '#';
    a.textContent = i;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      currentPage = i;
      loadBorrowingLogs_return(currentPage);
    });

    li.appendChild(a);
    pagination.appendChild(li);
  }

  // Next button
  const nextLi = document.createElement('li');
  nextLi.classList.add('page-item');
  if (currentPage === totalPages) nextLi.classList.add('disabled');

  const nextA = document.createElement('a');
  nextA.classList.add('page-link');
  nextA.href = '#';
  nextA.textContent = 'Next';

  nextA.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentPage < totalPages) loadBorrowingLogs_return(currentPage + 1);
  });

  nextLi.appendChild(nextA);
  pagination.appendChild(nextLi);
}

function update_to_returned(id) {
  if (confirm("Are you sure the book is already returned?")) {
    fetch('../backend/update_status_return.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `action=delete&borrow_id=${encodeURIComponent(id)}`
    })
    .then(response => response.json())
    .then(data => {
      alert("The book is returned successfully");
      loadBorrowingLogs_return();
    })
    // .catch(error => console.log(error));
  }
}
