// ---------------- Voice Search ------------ 
function startVoiceSearch() {
    let recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';

    recognition.onresult = function(event) {
        let voicetypequery = event.results[0][0].transcript;
        document.getElementById('textsearch').value = voicetypequery;
        document.getElementById('result').innerText = "Searching for: " + voicetypequery;
        fetchBooks(voicetypequery);
    };
    recognition.start();
}

function fetchBooks(voicetypequery) {
    let bookList = document.getElementById("bookList");
    bookList.innerHTML = ""; // Clear old results BEFORE fetch

    fetch(`../backend/search.php?GETvoicesearch=${voicetypequery}`)
    .then(response => response.json())
    .then(data => {
        let bookList = document.getElementById("bookList");
        bookList.innerHTML = "";
        
        if (data.length > 0) {
            data.forEach(book => {
                let li = document.createElement("li");
                const bookDetails = document.createElement("div");
                bookDetails.classList.add("book-details");
                bookDetails.innerHTML = `
                    <strong>Book Title: </strong> ${book.title} <br> <br>
                    <strong>Written by: </strong> ${book.author}<br>
                    <strong>Genre: </strong> <em>[${book.subject}]</em> ${book.pub_year} <br>
                    <strong>Book Ascension:</strong> ${book.acc_no} <strong> Book Call No: </strong> ${book.call_no}
                    `;
                // li.textContent = `${book.acc_no} ${book.call_no} ${book.title} by ${book.author} [${book.subject}] ${book.pub_year}`;
                
                const borrowBtn  = document.createElement("button");
                borrowBtn.textContent = "Borrow";
                borrowBtn.dataset.title = book.title;

                borrowBtn.addEventListener("click", () => {
                handleBorrowClick(book.title, book.acc_no, book.call_no);
                });
                li.appendChild(bookDetails);
                li.appendChild(borrowBtn);
                bookList.appendChild(li);
                });

        } else {
            bookList.innerHTML = "<li>No books found</li>";
        }
    })
    .catch(error => console.error("Error:", error));
}

// -------- Text Search -------------
function textsearch() {
    const textsearchquery = document.getElementById("textsearch").value;  
    if (textsearchquery.trim() !== "") {
        fetchtextsearch(textsearchquery);
    } else {
        document.getElementById("result").innerText = "Please enter a search term!";
    }
}

function fetchtextsearch(textsearchquery) {
    let textsearch_result = document.getElementById('textbookList');
    textsearch_result.innerHTML = ""; // Clear previous results

    fetch(`../backend/search.php?GETtextsearch=${textsearchquery}`)
        .then(response => response.json())
        .then(fulltextbooks => {
            let textsearch_result = document.getElementById('textbookList');
            textsearch_result.innerHTML = ""; // Clear previous results

            if (fulltextbooks.length > 0) {
                fulltextbooks.forEach(textbook => {
                    const list = document.createElement('li');
                    const bookDetails = document.createElement("div");
                    bookDetails.classList.add("book-details");
                    bookDetails.innerHTML = `
                        <strong>Book Title: </strong> ${textbook.text_title} <br> <br>
                        <strong>Written by: </strong> ${textbook.text_author}<br>
                        <strong>Genre: </strong> <em>[${textbook.text_subject}]</em> ${textbook.text_pubyear} <br>
                        <strong>Book Ascension:</strong> ${textbook.text_accno} <strong> Book Call No: </strong> ${textbook.text_callno}
                        `;
                    // list.textContent = `${textbook.text_accno} ${textbook.text_callno}  ${textbook.text_title} by ${textbook.text_author} [${textbook.text_subject}] ${textbook.text_pubyear}`;

                    const borrowBtn = document.createElement("button");
                    borrowBtn.textContent = "Borrow";
                    borrowBtn.dataset.title = textbook.text_title;

                    borrowBtn.addEventListener("click", () => {
                    handleBorrowClick(textbook.text_title, textbook.text_accno, textbook.text_callno);
                    });
                    list.appendChild(bookDetails);
                    list.appendChild(borrowBtn);
                    textsearch_result.appendChild(list);
                });
                
            } else {
                textsearch_result.innerHTML = "<li>No books found</li>";
            }
        })
        .catch(error => {
            console.error("Error:", error);
        });
}

// -------------- Borrow Handler -------------- 
function handleBorrowClick(selectedTitle, selectedAccno, selectedcallno) {
    fetch("../backend/get_booktitle.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
    body: 
      'selected_book_title=' + encodeURIComponent(selectedTitle) +
      '&selected_book_accno=' + encodeURIComponent(selectedAccno) +
      '&selected_book_callno=' + encodeURIComponent(selectedcallno)
    })
    .then(() => {
        return fetch("../backend/check_session.php");
    })
    .then(response => response.json())
    .then(data => {
        if (data.logged_in) {
            window.location.href = "../pages/book_borrow.html";
        } else {
            window.location.href = "../login/signin.html";
        }
    })
    .catch(error => {
        console.error("Borrow flow failed:", error);
        alert("Something went wrong.");
    });
}