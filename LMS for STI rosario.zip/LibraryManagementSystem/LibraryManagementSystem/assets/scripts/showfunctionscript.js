/**pagination */
let currentPage = 1;

function showPanel(panelId) {
  // Hide all panels
  document.querySelectorAll('.panel').forEach(panel => {
    panel.classList.remove('active');
  });
  // Show the selected panel
  document.getElementById(panelId).classList.add('active');

  // Remove active class from all buttons
  document.querySelectorAll('.sidebar button').forEach(button => {
    button.classList.remove('active-btn');
  });


  const sidebarButtons = {
    'dashboard': 'Dashboard_btn',
    'borrowPanel': 'Borrow-btn',
    'returnPanel': 'Return_btn', 
    'employee': 'Employee_btn',
    'books': 'Books_btn',       
    'logsPanel': 'logs-btn',
    'DeleteBook': 'Del-btn'
  };

  const buttonId = sidebarButtons[panelId];
  if (buttonId) {
    const btn = document.getElementById(buttonId);
    if (btn) {
      btn.classList.add('active-btn');
    }
  }

  if (panelId === 'books') {
    loadBooks(currentPage);
  } else if (panelId === 'employee') {
    loadUsers(currentPage);
  } else if (panelId === 'borrowPanel'){
    loadBorrowingLogs(currentPage);
  } else if (panelId === 'returnPanel'){
    loadBorrowingLogs_return(currentPage)
  } else if (panelId === 'logsPanel') {
    loadBorrowingLogs_logs(currentPage)
  } else if (panelId === 'DeleteBook') {
    loadBorrowingLogs_logs(currentPage)
  }
  
}

function loadBooks(page = 1) {
  fetch(`../backend/book_management.php?page=${page}`)
    .then(response => response.json())
    .then(data => {
      document.getElementById('bookTableBody').innerHTML = data.books;
      setupPagination(data.totalPages, page);
    })
    .catch(error => {
      document.getElementById('bookTableBody').innerHTML = "Error loading book list.";
      console.error("Error loading book_management.php:", error);
    });
}

/*start of pagination*/
function setupPagination(totalPages, currentPage) {
  const pagination = document.getElementById('bookpagination');
  pagination.innerHTML = '';

  // Previous Button
  const prevLi = document.createElement('li');
  prevLi.classList.add('page-item');
  if (currentPage === 1) prevLi.classList.add('disabled');

  const prevA = document.createElement('a');
  prevA.classList.add('page-link');
  prevA.href = '#';
  prevA.textContent = 'Previous';
  prevA.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentPage > 1) {
      currentPage--;
      loadBooks(currentPage);
    }
  });

  prevLi.appendChild(prevA);
  pagination.appendChild(prevLi);

  // Determine page number range (show only 3 pages at a time)
  let start = Math.max(currentPage - 1, 1);
  let end = Math.min(start + 2, totalPages);

  // Adjust start if we're at the end
  start = Math.max(end - 2, 1);

  for (let i = start; i <= end; i++) {
    const li = document.createElement('li');
    li.className = `page-item ${i === currentPage ? 'active' : ''}`;

    const a = document.createElement('a');
    a.classList.add('page-link');
    a.href = '#';
    a.textContent = i;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      currentPage = i;
      loadBooks(currentPage);
    });

    li.appendChild(a);
    pagination.appendChild(li);
  }

  // Next Button
  const nextLi = document.createElement('li');
  nextLi.classList.add('page-item');
  if (currentPage === totalPages) nextLi.classList.add('disabled');

  const nextA = document.createElement('a');
  nextA.classList.add('page-link');
  nextA.href = '#';
  nextA.textContent = 'Next';
  nextA.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentPage < totalPages) {
      currentPage++;
      loadBooks(currentPage);
    }
  });

  nextLi.appendChild(nextA);
  pagination.appendChild(nextLi);
}
/*end of pagination */
  function addBook() {
    dialogbox("Add Book button clicked!");
}

// =============================================== MODAL FOR BOOK  
function openModal() {
  document.getElementById('addBookForm').reset();
  document.getElementById('bookId').value = ""; // Clear hidden ID field
  document.querySelector('#myModal h2').textContent = "Add Book";
  document.querySelector('#addBookForm button[type="submit"]').textContent = "Add";
  document.getElementById('addBookForm').onsubmit = submitBookForm;
  document.getElementById("myModal").style.display = "flex"; 
}

function closeModal() {
  document.getElementById('myModal').style.display = "none";
  document.getElementById('addBookForm').reset();
  document.getElementById('bookId').value = ""; // Clear ID
  document.getElementById('addBookForm').onsubmit = submitBookForm;
}

// =============================================== UPDATE FUNCTION FOR BOOKS 
function openUpdateModal(id, accNo,author,title, isbn, callNo,classNo, cutterNo,bookpublished,copyNo,subject,pages,publisher,place) {
  document.getElementById('bookId').value = id;
  document.getElementById('accNo').value = accNo;
  document.getElementById('author').value = author;
  document.getElementById('title').value = title;
  document.getElementById('isbn').value = isbn;
  document.getElementById('callNo').value = callNo;
  document.getElementById('classNo').value = classNo;
  document.getElementById('cutterNo').value = cutterNo;
  document.getElementById('year').value = bookpublished;
  document.getElementById('copyNo').value = copyNo;
  document.getElementById('subject').value = subject;
  document.getElementById('pages').value = pages;
  document.getElementById('publisher').value = publisher;
  document.getElementById('place').value = place;

  
  document.querySelector('#myModal h2').textContent = "Update Book";
  document.querySelector('#addBookForm button[type="submit"]').textContent = "Update";
  document.getElementById('addBookForm').onsubmit = submitUpdateForm;
  document.getElementById('myModal').style.display = "flex";
}

function submitUpdateForm(event) {
  event.preventDefault();
  const id = document.getElementById('bookId').value.trim();
  const accNo = document.getElementById('accNo').value.trim();
  const author = document.getElementById('author').value.trim();
  const title = document.getElementById('title').value.trim();
  const isbn = document.getElementById('isbn').value.trim();
  const callNo = document.getElementById('callNo').value.trim();
  const classNo = document.getElementById('classNo').value.trim();
  const cutterNo = document.getElementById('cutterNo').value.trim();
  const year = document.getElementById('year').value.trim();
  const copyNo = document.getElementById('copyNo').value.trim();
  const subject = document.getElementById('subject').value.trim();
  const pages = document.getElementById('pages').value.trim();
  const publisher = document.getElementById('publisher').value.trim();
  const place = document.getElementById('place').value.trim();

  if (!accNo || !author || !title || !isbn || !year || !copyNo || !pages || !publisher || !place) {
    alert("Please fill in all required fields.");
    return;
  }

  const formData =
    'id=' + encodeURIComponent(id) +
    '&accNo=' + encodeURIComponent(accNo) +
    '&bookAuthor=' + encodeURIComponent(author) +
    '&bookTitle=' + encodeURIComponent(title) +
    '&isbn=' + encodeURIComponent(isbn) +
    '&callNo=' + encodeURIComponent(callNo) +
    '&classNo=' + encodeURIComponent(classNo) +
    '&cutterNo=' + encodeURIComponent(cutterNo) +
    '&bookpublished=' + encodeURIComponent(year) +
    '&bookquantity=' + encodeURIComponent(copyNo) + // FIXED: must match backend expected name
    '&subject_heading=' + encodeURIComponent(subject) +
    '&pages=' + encodeURIComponent(pages) +
    '&publisher=' + encodeURIComponent(publisher) +
    '&place_of_publication=' + encodeURIComponent(place);

  fetch('../backend/update_book.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    console.log(data);
    closeModal();
    document.getElementById("addBookForm").reset();
    showPanel('books');
    loadBooks();
  })
  .catch(error => alert("Error: " + error));
}


document.addEventListener('click', function (e) {
  if (e.target.classList.contains('update-btn')) {
    e.preventDefault();

    const btn = e.target;
    document.getElementById('bookId').value = btn.dataset.id;
    document.getElementById('accNo').value = btn.dataset.accno;
    document.getElementById('author').value = btn.dataset.author;
    document.getElementById('title').value = btn.dataset.title;
    document.getElementById('isbn').value = btn.dataset.isbn;
    document.getElementById('callNo').value = btn.dataset.callno;
    document.getElementById('classNo').value = btn.dataset.classno;
    document.getElementById('cutterNo').value = btn.dataset.cutterno;
    document.getElementById('copyNo').value = btn.dataset.copyno;
    document.getElementById('year').value = btn.dataset.bookpublished;
    document.getElementById('subject').value = btn.dataset.subject;
    document.getElementById('pages').value = btn.dataset.pages;
    document.getElementById('publisher').value = btn.dataset.publisher;
    document.getElementById('place').value = btn.dataset.place;
    
    document.querySelector('#myModal h2').textContent = "Update Book";
    document.querySelector('#addBookForm button[type="submit"]').textContent = "Update";
    document.getElementById('addBookForm').onsubmit = submitUpdateForm;
    document.getElementById('myModal').style.display = "flex";
  }
});
 

// =============================================== SAVE FUNCTION FOR BOOK 
function submitBookForm(event) {
  event.preventDefault(); // Prevent form from refreshing the page
  const accNo = document.getElementById('accNo').value.trim();
  const author = document.getElementById('author').value.trim();
  const title = document.getElementById('title').value.trim();
  const isbn = document.getElementById('isbn').value.trim();
  const callNo = document.getElementById('callNo').value.trim();
  const classNo = document.getElementById('classNo').value.trim();
  const cutterNo = document.getElementById('cutterNo').value.trim();
  const year = document.getElementById('year').value.trim();
  const copyNo = document.getElementById('copyNo').value.trim();
  const subject = document.getElementById('subject').value.trim();
  const pages = document.getElementById('pages').value.trim();
  const publisher = document.getElementById('publisher').value.trim();
  const place = document.getElementById('place').value.trim();
  const bookentry = new Date().toISOString().slice(0, 19).replace('T', ' ');
  if (!accNo || !author || !title || !isbn || !year || !copyNo || !pages || !publisher || !place) {
    alert("Please fill in all required fields.");
    return;
  }
  const formData =
    'accNo=' + encodeURIComponent(accNo) +
    '&bookAuthor=' + encodeURIComponent(author) +
    '&bookTitle=' + encodeURIComponent(title) +
    '&isbn=' + encodeURIComponent(isbn) +
    '&callNo=' + encodeURIComponent(callNo) +
    '&classNo=' + encodeURIComponent(classNo) +
    '&cutterNo=' + encodeURIComponent(cutterNo) +
    '&bookpublished=' + encodeURIComponent(year) +
    '&copy_no=' + encodeURIComponent(copyNo) +
    '&subject_heading=' + encodeURIComponent(subject) +
    '&pages=' + encodeURIComponent(pages) +
    '&publisher=' + encodeURIComponent(publisher) +
    '&place_of_publication=' + encodeURIComponent(place);
  fetch('../backend/add_book.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: formData
  })
  .then(response => response.text())
  .then(data => {
      console.log(data); // =========================================== Shows success or error message // delete this after 
      closeModal(); // Close the modal
      document.getElementById("addBookForm").reset(); 
      showPanel('books'); 
  })
  .catch(error => {
      alert("Error: " + error);
  });
}

// =============================================== DELETE FUNCTION FOR BOOK 
// Delete
function loadDeletedBooks() {
  fetch('../backend/load_deleted_books.php')
    .then(res => res.text())
    .then(html => {
      document.getElementById('book_deletion').innerHTML = html;
    });
}

// Call this once on page load too
loadDeletedBooks();

function deleteBook(bookId) {
  const dialog = document.getElementById('confirmDialog');
  dialog.style.display = 'block';

  const yesBtn = document.getElementById('confirmYes');
  const noBtn = document.getElementById('confirmNo');

  yesBtn.onclick = null;
  noBtn.onclick = null;

  yesBtn.onclick = (e) => {
    e.preventDefault();

    const details = document.getElementById('details').value.trim();
    if (details === '') {
      alert('Please select a return issue (e.g. damage, lost, replace).');
      return;
    }

    fetch(`../backend/report_issue.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: `book_id=${encodeURIComponent(bookId)}&issue_type=${encodeURIComponent(details)}`
    })
    .then(response => response.text())
    .then(data => {
      console.log(data);

      // Hide dialog and reset
      dialog.style.display = 'none';
      document.getElementById('details').value = '';

      // ✅ Remove the row from the table
      const row = document.getElementById(`user-row-${bookId}`);
      if (row) row.remove();

      alert('The issue was logged successfully.');

      // ✅ Reload the deleted books list (see next step)
      loadDeletedBooks();
    });
  };

  noBtn.onclick = () => {
    dialog.style.display = 'none';
    document.getElementById('details').value = '';
  };
}

//close dialog delete
function closeDialog() {
  const dialog = document.getElementById('confirmDialog');
  dialog.style.display = 'none';
}

window.onload = function() {
  loadDeletedBooks();
};
