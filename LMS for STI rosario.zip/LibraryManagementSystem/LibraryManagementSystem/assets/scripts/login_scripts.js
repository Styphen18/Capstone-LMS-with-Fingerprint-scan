function togglePassword() {
    const pwd = document.getElementById("password");
    const icon = document.getElementById("eyeIcon");
  
    if (pwd.type === "password") {
        pwd.type = "text";
        con.className = "bi bi-eye-fill";
    } else {
        pwd.type = "password";
        icon.className = "bi bi-eye-slash-fill";
    }
}

