// Modal for Homepage01
function openModal_borrowing(type, message) {
    const modal = document.getElementById('modal-container');
    const title = document.getElementById('modal-title');
    const msg = document.getElementById('modal-message');

    if (type === 'success') {
        title.innerText = 'Success!';
        msg.innerText = message || 'Book borrow request submitted successfully.';
        modal.classList.add('success');
        modal.classList.remove('error');
    } else if (type === 'error') {
        title.innerText = 'Error!';
        msg.innerText = message || 'Something went wrong.';
        modal.classList.add('error');
        modal.classList.remove('success');
    }
    modal.classList.add('active');
}

function closeModal_borrowing() {
    // document.getElementById('modal-container').classList.remove('active');
    window.location.href = "../pages/homepage01.php";

}

document.addEventListener("DOMContentLoaded", function() {
    const urlParams = new URLSearchParams(window.location.search);
    const borrowStatus = urlParams.get('borrow');

    if (borrowStatus === 'successful') {
        openModal_borrowing('success', 'Your borrow request was successful! \n\nAn Email have been sent to you for you borrowing details.');
    } else if (borrowStatus === 'error_quantity_low') {
        openModal_borrowing('error', 'Cannot borrow — Not enough copies available.');
    } else if (borrowStatus === 'error_no_book_found') {
        openModal_borrowing('error', 'Book not found in the system.');
    } else if (borrowStatus === 'error_insert') {
        openModal_borrowing('error', 'An error occurred while saving your request.');
    } else if (borrowStatus === 'error_pending_limit' ) {
        openModal_borrowing('error', 'Cannot Borrow — User have 2 or More Pending Borrow Request \n\nUser can only borrow two books' )
    }
});

// modal for borrow_list btn 

function user_borrow_list(){
 fetch("../backend/borrow_list.php")
 .then(response  => response.text())
 .then(borrow_list => {
    document.getElementById('modal-title').innerHTML = "Total Borrow Books";
    document.getElementById("modal-message").innerHTML = borrow_list;
    document.getElementById("modal-container").classList.add("active");
 })
}