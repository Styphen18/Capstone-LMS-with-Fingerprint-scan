function startFingerprint() {
    fetch("../backend/Fingerprint_exe_run.php")
        .then(response => response.text())
        .then(data => data)
        .catch(error => alert("Error: " + error));
}

function Time_in() {
    fetch("../backend/Attedance/time_in_attendance.php")
        .then(response => response.text())
        .then(data =>  data)
        .catch(error => alert("Error: " + error));
}

function Time_out() {
    fetch("../backend/Attedance/time_out_attendance.php")
        .then(response => response.text())
        .then(data =>  data)
        .catch(error => alert("Error: " + error));
}