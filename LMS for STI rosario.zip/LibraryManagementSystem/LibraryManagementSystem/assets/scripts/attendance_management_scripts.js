let filterActive = false;

document.addEventListener("DOMContentLoaded", () => {
    load_attendance_users();
    setdateToday();
    setInterval(() => {
    if (!filterActive) {
        load_attendance_users();
    }}, 5000);
});

function setdateToday() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById("dateFilter").value = today;
}

function load_attendance_users() {
  fetch('../backend/attendance_management.php') 
    .then(response => response.json())
    .then(data => {
      let htmlContent = '';

      data.forEach(user => {
        htmlContent += `
          <tr>
            <td>${user.studentid}</td>
            <td>${user.fullname}</td>
            <td>${user.course}</td> 
            <td>${user.timein ?? ""}</td>
            <td>${user.timeout ?? ""}</td>
          </tr>
        `;
    });
        document.getElementById('attendance_table').innerHTML = htmlContent;
    })
    .catch(error => {
      document.getElementById('attendance_table').innerHTML = "Error loading user list.";
      console.error("Error loading Attendance:", error);
    });
}

function filterDate() {
    const date = document.getElementById("dateFilter").value;

    if (!date) {
        alert("Please select a date first.");
        return;
    }
    
    filterActive = true;

    fetch(`../backend/attendance_management.php?date=${date}`)
        .then(res => res.json())
        .then(data => {
            let html = "";
            data.forEach(user => {
                html += `
                <tr>
                    <td>${user.studentid}</td>
                    <td>${user.fullname}</td>
                    <td>${user.course}</td>
                    <td>${user.timein}</td>
                    <td>${user.timeout}</td>
                </tr>`;
            });
            document.getElementById("attendance_table").innerHTML = html;
        });
}


function clear_attendance_records() {
    if (confirm("Clear the table display? (This will NOT delete the database records)")) {
        document.getElementById('attendance_table').innerHTML = "";
    }
}

function clearFilter() {
    document.getElementById("dateFilter").value = "";
    filterActive = false;
    setdateToday();
    load_attendance_users(); // loads full table again
}
