<html>

<head>
    <title>Attendance Page</title>
    <link rel="stylesheet" href="../assets/styles/attendance_page.css">
    <script src="../assets/scripts/Fingerprint_btn.js"></script>
    <script src="../assets/scripts/attendance_management_scripts.js"></script>

</head>

<body>
    <h1>Attendance Page</h1>
    <p>This is the attendance page, accessible only to Librarian users.</p>

    <div class="date-filter">
        <label>*Select date to view attendance</label>
        <input type="date" id="dateFilter">
        <button class="btn" onclick="filterDate()">Filter</button>
        <button class="btn" onclick="clearFilter()">Clear</button>
    </div>

    <div class="time-buttons">
        <button id="time-in-btn" type="button" onclick="Time_in()"> Time in </button>
        <button id="time-out-btn" type="button" onclick="Time_out()"> Time out </button>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Fullname</th>
                <th>Course | Department</th>
                <th>Time of Entry</th>
                <th>Time of Exit</th>
            </tr>
        </thead>
        <tbody id="attendance_table" class="table-group-divider">
        </tbody>
    </table>
</body>

</html>