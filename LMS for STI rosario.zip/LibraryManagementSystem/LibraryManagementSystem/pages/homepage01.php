<?php
session_start();


if (!isset($_SESSION['email'])) {  // If user is not logged in
  header("Location: ../login/signin.html");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Homepage</title>

  <!-- for mic logo -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <!-- CSS -->
  <link rel="stylesheet" href="../assets/styles/homepage01.css" />
  <link rel="stylesheet" href="../assets/styles/modal_design.css" />
  <link rel="stylesheet" href="../assets/styles/search_items_homepage.css" />
  <script src="../assets/scripts/script.js"></script>
  <script src="../assets/scripts/Modals.js"></script>

</head>

<body>
  <div class="page-frame">

    <!-- TOP BAR with title and nav -->
    <div class="nav-and-heading">
      <div class="left-top">
        <h1 class="school-title">STI College Rosario Library</h1>
        <div class="remembertomakethisgrid">
          <!-- Button Attendance condition for showing( If not admin then not show) -->
          <?php if ($_SESSION['role'] === 'Librarian'): ?>
            <a href="attendance.php">Attendance</a>
          <?php endif; ?>

          <a href="homepage01.php">Home</a>
          <a href="About.html">About</a>
          <a href="Contact.html">Contact</a>
          <a href="Service.html">Services</a>
          <a href="../backend/logout.php">Log out</a>
        </div>
      </div>
    </div>

    <div class="mainlayout">
      <!-- LEFT SIDE -->
      <div class="containerHM">
        <p class="tagline">Just Say it — Your Next<br>Book Is Listening!</p>

        <div class="formforsearchbar">
          <input type="text" id="textsearch" name="textsearch" placeholder="Search for Books">
          <button onclick="textsearch()"> Search </button>
          <button onclick="startVoiceSearch()"><i class="fas fa-microphone"></i></button>
        </div>

        <button id="borrowlist" onclick="user_borrow_list()">Borrow Request Preview</button>
      </div>

      <!-- RIGHT SIDE -->
      <div class="border-output">
        <div class="containerforvoicesearch">
          <p id="result"></p>
          <ul id="bookList"></ul>
          <ul id="textbookList"></ul>
        </div>
      </div>
    </div>


    <!-- MODAL -->
    <div class="modal_container" id="modal-container">
      <div class="modal">
        <h1 id="modal-title">Modal Title</h1>
        <p id="modal-message">Modal MSG DESCRIPTION</p>
        <button onclick="closeModal_borrowing()">Close</button>
      </div>
    </div>
  </div>


</body>

</html>