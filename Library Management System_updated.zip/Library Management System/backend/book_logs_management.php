<?php
session_start();
include 'connect.php';
header('Content-Type: application/json; charset=UTF-8');

function safeAttr($value)
{
    return htmlspecialchars(trim(str_replace(["\n", "\r"], '', $value)), ENT_QUOTES);
}

// Pagination variables
$limit = 10; // Items per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1); // Prevent negative or zero page
$offset = ($page - 1) * $limit;

$totalQuery = $conn->query("SELECT COUNT(*) AS total_borrower FROM borrowrequest_logs WHERE borrow_status = 'returned'");
$totalRow = $totalQuery->fetch_assoc();
$totalUser = $totalRow['total_borrower'];
$totalPages = ceil($totalUser / $limit);

// Fetch paginated user
$sql = "SELECT * FROM borrowrequest_logs WHERE borrow_status = 'returned' ORDER BY borrow_id DESC LIMIT $offset, $limit";
$result = $conn->query($sql);

// Build user row
$userRows = "";
while ($row = $result->fetch_assoc()) {

    $borrow_id_logs  = $row['borrow_id'];
    $name_borrower_logs = safeAttr($row['borrow_name']);
    $course_department_borrower_logs = safeAttr($row['borrow_course']);
    $student_faculty_id_borrower_logs = safeAttr($row['borrow_studentid']);
    $contact_borrower_logs = safeAttr($row['borrow_contact']);
    // $borrower_mail = safeAttr($_SESSION['email']);
    $borrower_mail_logs = isset($_SESSION['email']) ? safeAttr($_SESSION['email']) : 'unknown';
    $book_title_logs = safeAttr($row['borrow_booktitle']);
    $book_borrow_date_logs = safeAttr($row['borrow_date']);
    $book_logs_date_logs = safeAttr($row['borrow_return_date']);
    $borrow_status_logs = safeAttr($row['borrow_status']);

    $userRows .= "
    <tr id='user-row-{$borrow_id_logs}'>
        <td>{$borrow_id_logs}</td>
        <td>{$name_borrower_logs}</td>
        <td>{$course_department_borrower_logs}</td>
        <td>{$student_faculty_id_borrower_logs}</td>
        <td>{$contact_borrower_logs}</td>
        <td>{$borrower_mail_logs}</td>
        <td>{$book_title_logs}</td>
        <td>{$book_borrow_date_logs}</td>
        <td>{$book_logs_date_logs}</td>
        <td>{$borrow_status_logs}</td>
    </tr>
    ";
}

// Return JSON
echo json_encode([
    'borrows_logs' => $userRows,
    'totalPages' => $totalPages
]);
