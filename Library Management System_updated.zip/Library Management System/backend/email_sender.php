<?php
require_once '../PHPmailer/PHPMailer.php';
require_once '../PHPmailer/SMTP.php';
require_once '../PHPmailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendEmail($email, $otp)
{
    $mail = new PHPMailer(true);

    try {

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'noreply.lms.test@gmail.com';
        $mail->Password = 'kzjc wcnf tgdz vkry'; // Gmail App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        //Sender
        $mail->setFrom('noreply.lms.test@gmail.com', 'STI College Rosario Library System');
        $mail->addAddress($email);

        // ONLY for local dev (disable in live server)
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];

        // Email for OTP
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body = "Your OTP code is: <b>$otp</b>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        return "Mailer Error: {$mail->ErrorInfo}";
    }
}

// Email for Borrowing 
function sendEmail_for_borrower($email, $user_name, $user_number, $user_course, $user_contactnum, $borrow_booktitle, $borrow_time, $borrow_return)
{
    $mail_for_borrower = new PHPMailer(true);

    try {
        $mail_for_borrower->isSMTP();
        $mail_for_borrower->Host = 'smtp.gmail.com';
        $mail_for_borrower->SMTPAuth = true;
        $mail_for_borrower->Username = 'noreply.lms.test@gmail.com';
        $mail_for_borrower->Password = 'kzjc wcnf tgdz vkry'; // Gmail App Password
        $mail_for_borrower->SMTPSecure = 'tls';
        $mail_for_borrower->Port = 587;

        //Sender
        $mail_for_borrower->setFrom('noreply.lms.test@gmail.com', 'STI College Rosario Library System');
        $mail_for_borrower->addAddress($email);

        // ONLY for local dev (disable in live server)
        $mail_for_borrower->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];

        // Email for OTP
        $mail_for_borrower->isHTML(true);
        $mail_for_borrower->Subject = 'Borrowing Details';
        $mail_for_borrower->Body = "
            <h2>Library Borrowing Confirmation</h2>
            <p>Dear <strong>$user_name</strong>,</p>

            <p>Thank you for borrowing from our library. Below are the details of your transaction:</p>

            <p><strong>Name:</strong> $user_name</p>
            <p><strong>Student/Faculty ID:</strong> $user_number</p>
            <p><strong>Course/Department:</strong> $user_course</p>
            <p><strong>Contact Number:</strong> $user_contactnum</p>
            <p><strong>Book Title:</strong> $borrow_booktitle</p>
            <p><strong>Date Borrowed:</strong> $borrow_time</p>
            <p><strong>Return Due Date:</strong> <b>$borrow_return</b></p>

            <p>Please present this email to the librarian when claiming the book.</p>
            <p><strong>Reminder:</strong> Books must be returned on or before <b>$borrow_return</b>. A late fee of <strong>₱5.00 per day</strong> will be applied for overdue returns.</p>

            <p>Thank you,<br>Library Services</p>
        ";


        $mail_for_borrower->send();
        return true;
    } catch (Exception $e) {
        return "Mailer Error: {$mail_for_borrower->ErrorInfo}";
    }
}
