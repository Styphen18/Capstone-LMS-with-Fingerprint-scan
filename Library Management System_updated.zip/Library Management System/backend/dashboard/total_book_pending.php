<?php
include '../connect.php';

// Pending Dashboard count
$sql = "SELECT COUNT(*) AS total_pending FROM borrowrequest_logs WHERE borrow_status = 'pending'";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    echo $row['total_pending'];
} else {
    echo 0;
}
