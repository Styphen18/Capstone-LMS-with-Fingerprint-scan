<?php
include 'connect.php';

date_default_timezone_set('Asia/Manila');

if (!isset($_POST['bookTitle']) || !isset($_POST['bookAuthor'])) {
    die("Missing data: " . json_encode($_POST));
}
$title = $_POST['bookTitle'];
$author = $_POST['bookAuthor'];
$published = $_POST['bookpublished'];
$quantity = $_POST['bookquantity'];
$genre = $_POST['genre'];
$bookentry = date('Y-m-d H:i:s');

$sql_check_booktitle = "SELECT booktitle FROM booktry WHERE booktitle = '$title'";
$result = $conn->query($sql_check_booktitle);

if ($result && $result->num_rows == 0) {
    $sql = "INSERT INTO booktry (booktitle, bookauthor, bookpublished, bookquantity, genre, bookentry) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sssiss", $title, $author, $published, $quantity, $genre, $bookentry);

    if ($stmt->execute()) {
        echo "success"; 
    } else {
        echo "Execute failed: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo " The Book is already in database, Update the Quantity instead.";            // FIX THIS CHANGE THE ERROR HANDLER
}

$conn->close();
?>  